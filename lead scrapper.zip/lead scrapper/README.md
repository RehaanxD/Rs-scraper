# R Scrapper

A **fully local** lead-scraping tool for finding clients for your web development / automation business.

## Features

- **Google Maps scraper** — extracts name, phone, address, website, rating, category
- **Web search** — Google, Bing, DuckDuckGo with stealth anti-detection
- **Lead scoring** — A/B/C/D grades based on: no website, bad website, no SSL, not mobile-friendly, no social, etc.
- **Website quality audit** — checks SSL, mobile-friendliness, load time, modern tech detection
- **Social profile extraction** — Facebook, Instagram, Twitter, LinkedIn, TikTok, YouTube, WhatsApp
- **Deep email finder** — crawls /contact, /about, and other pages for emails and phones
- **Cross-source deduplication** — same business from Maps + web search merges into one lead
- **Proxy rotation** — configure via env var for rotating IPs
- **Scheduled searches** — create recurring searches with configurable intervals
- **Excel export** — formatted .xlsx with color-coded grades and conditional highlighting
- **Dashboard** — stats overview with grade distribution, source breakdown, tag analytics
- **Stealth browsing** — real Chrome, fingerprint masking, human-like behavior, CAPTCHA detection

## Quick start

```powershell
cd "C:\Users\rehaa\Desktop\lead scrapper"
python -m pip install -r requirements.txt
python -m playwright install chromium
python -m backend.app.main
```

Open `http://127.0.0.1:8000/`

## UI Tabs

| Tab | Description |
|---|---|
| **Maps** | Google Maps search. Tick "no website only" to get best leads. Auto-audits websites found. |
| **Web Search** | Google/Bing/DDG web search + page scanning |
| **Leads** | Browse, filter by score/grade/source/tag. Export CSV, Excel, or JSON. |
| **Schedules** | Create recurring searches. Run manually or on a timer. |
| **Dashboard** | Stats: total leads, grades, sources, tags, average score |

## API

| Endpoint | Method | Description |
|---|---|---|
| `/api/maps-search` | POST | Search Google Maps |
| `/api/search` | POST | Web search + scan |
| `/api/leads` | GET | List leads (filters: tag, source, grade, min_score, no_website_only) |
| `/api/leads/{id}` | GET/DELETE | Single lead |
| `/api/export.csv` | GET | CSV export |
| `/api/export.xlsx` | GET | Excel export with formatting |
| `/api/stats` | GET | Dashboard statistics |
| `/api/schedules` | GET/POST | List/create scheduled searches |
| `/api/schedules/{id}` | DELETE | Delete schedule |
| `/api/schedules/{id}/run` | POST | Run schedule now |
| `/api/scan-url` | POST | Scan a single URL |

## Proxy setup (optional)

Set the env var to rotate through proxies:

```powershell
$env:LEAD_SCRAPER_PROXY_LIST = "http://user:pass@proxy1:8080,http://user:pass@proxy2:8080"
python -m backend.app.main
```

## Lead scoring

| Factor | Score impact |
|---|---|
| No website | +30 |
| Bad website (quality < 30) | +20 |
| No SSL | +10 |
| Not mobile-friendly | +10 |
| Has phone number | +5 |
| Has email | +5 |
| No social profiles | +5 |
| Good Maps rating (4+) | +5 |
| Many reviews (50+) | +5 |
| Automation intent signals | up to +15 |

Grades: **A** (80+), **B** (60-79), **C** (40-59), **D** (0-39)
