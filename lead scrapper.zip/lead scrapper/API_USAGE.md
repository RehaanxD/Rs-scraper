## R Scrapper API & CLI usage

This document shows how to drive **R Scrapper** from the terminal, scripts, or other apps.

The server must be running first:

```powershell
cd "C:\Users\rehaa\Desktop\lead scrapper"
python -m backend.app.main
```

Base URL: `http://127.0.0.1:8000`

All API paths below are relative to `/api`.

---

### 1. Search Google Maps

**Endpoint**

- `POST /api/maps-search`

**Body**

```json
{
  "query": "plumber Manchester UK",
  "max_results": 20,
  "tag": "plumbers-manchester",
  "only_no_website": true
}
```

**PowerShell example**

```powershell
$body = @{
  query = "plumber Manchester UK"
  max_results = 10
  tag = "plumbers-manchester"
  only_no_website = $true
} | ConvertTo-Json

Invoke-RestMethod `
  -Uri "http://127.0.0.1:8000/api/maps-search" `
  -Method Post `
  -ContentType "application/json" `
  -Body $body
```

This will:

- Open Google Maps in a real browser
- Scroll the results
- Extract: name, phone, address, rating, reviews, website
- For each website, run a **site audit** and deep email finder
- Save deduped leads into SQLite

---

### 2. Web search (Google / Bing / DuckDuckGo)

**Endpoint**

- `POST /api/search`

**Body**

```json
{
  "engine": "bing",
  "query": "car rental dubai email",
  "location_hint": "Dubai, UAE",
  "max_results": 20,
  "tag": "car-rentals-dubai",
  "only_no_website": false
}
```

**PowerShell example**

```powershell
$body = @{
  engine = "bing"
  query  = "car rental dubai email"
  location_hint = "Dubai, UAE"
  max_results = 20
  tag = "car-rentals-dubai"
  only_no_website = $false
} | ConvertTo-Json

Invoke-RestMethod `
  -Uri "http://127.0.0.1:8000/api/search" `
  -Method Post `
  -ContentType "application/json" `
  -Body $body
```

---

### 3. Scan a single URL

**Endpoint**

- `POST /api/scan-url`

**Body**

```json
{
  "url": "https://example.com",
  "engine": "google",
  "search_query": "example lead",
  "tag": "manual-scan"
}
```

**PowerShell**

```powershell
$body = @{
  url = "https://example.com"
  engine = "google"
  search_query = "example lead"
  tag = "manual-scan"
} | ConvertTo-Json

Invoke-RestMethod `
  -Uri "http://127.0.0.1:8000/api/scan-url" `
  -Method Post `
  -ContentType "application/json" `
  -Body $body
```

---

### 4. Listing and filtering leads

**Endpoint**

- `GET /api/leads`

**Query params**

- `limit` (int, default 200)
- `offset` (int)
- `tag` (string)
- `source` (`google_maps`, `google`, `bing`, `ddg`)
- `no_website_only` (bool)
- `min_score` (int 0–100)
- `grade` (`A`, `B`, `C`, `D`)

**Examples**

```powershell
# All leads
Invoke-RestMethod "http://127.0.0.1:8000/api/leads"

# Only A-grade, no-website, Maps leads tagged 'plumbers-manchester'
Invoke-RestMethod `
  "http://127.0.0.1:8000/api/leads?source=google_maps&tag=plumbers-manchester&no_website_only=true&grade=A"
```

---

### 5. Export CSV and Excel

**CSV**

- `GET /api/export.csv`

**Excel**

- `GET /api/export.xlsx`

Both accept the same filters as `/api/leads`:

- `tag`, `source`, `no_website_only`

**Examples**

```powershell
# CSV
Invoke-WebRequest `
  "http://127.0.0.1:8000/api/export.csv?source=google_maps&no_website_only=true" `
  -OutFile "maps_no_website.csv"

# Excel
Invoke-WebRequest `
  "http://127.0.0.1:8000/api/export.xlsx?source=google_maps&no_website_only=true" `
  -OutFile "maps_no_website.xlsx"
```

---

### 6. Dashboard stats

**Endpoint**

- `GET /api/stats`

Returns:

- `total_leads`, `no_website`, `has_website`
- `with_phone`, `with_email`
- `grades` (A/B/C/D counts)
- `sources` (per engine)
- `tags` (top tags)
- `avg_lead_score`

**Example**

```powershell
Invoke-RestMethod "http://127.0.0.1:8000/api/stats"
```

---

### 7. Scheduled searches

You can manage schedules via API or from the **Schedules** tab in the UI.

**Create schedule**

- `POST /api/schedules`

Body:

```json
{
  "search_type": "maps",
  "query": "plumber London",
  "max_results": 20,
  "tag": "plumbers-london",
  "only_no_website": true,
  "interval_minutes": 60
}
```

**Run now**

- `POST /api/schedules/{id}/run`

**List**

- `GET /api/schedules`

**Delete**

- `DELETE /api/schedules/{id}`

---

### 8. Distributed IPs / proxy rotation

R Scrapper supports **proxy rotation**, which gives you effectively distributed IPs as long as you provide a pool of proxies.

Two ways to configure:

#### 8.1 Environment variable

```powershell
$env:LEAD_SCRAPER_PROXY_LIST = "http://user:pass@proxy1:8080,http://user:pass@proxy2:8080,socks5://proxy3:1080"
python -m backend.app.main
```

Each browser session randomly picks one of these entries.

#### 8.2 `data/proxies.txt` file

Create `data\proxies.txt` with one proxy per line:

```text
# one per line, comments allowed
http://user:pass@proxy1:8080
http://user:pass@proxy2:8080
socks5://user:pass@proxy3:1080
```

R Scrapper will automatically read this file and rotate between these IPs as well as any proxies in the env variable.

> Note: you are responsible for obtaining proxy IPs (residential / datacenter). The app just rotates and uses them; it does not buy or manage proxies for you.

---

### 9. Using from Python scripts

You can easily call the API from your own Python tooling:

```python
import requests

BASE = "http://127.0.0.1:8000/api"

def maps_search(query: str, max_results: int = 20):
    r = requests.post(
        f"{BASE}/maps-search",
        json={
            "query": query,
            "max_results": max_results,
            "only_no_website": True,
            "tag": "python-script",
        },
        timeout=600,
    )
    r.raise_for_status()
    return r.json()


if __name__ == "__main__":
    data = maps_search("plumber Manchester UK", max_results=10)
    print("Saved leads:", data["saved"])
```

