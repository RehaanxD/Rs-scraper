from __future__ import annotations

from typing import List

from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="LEAD_SCRAPER_", case_sensitive=False)

    host: str = "127.0.0.1"
    port: int = 8000
    reload: bool = False
    log_level: str = "info"

    db_path: str = "data/leads.db"

    # Scraper behavior
    headless: bool = True
    nav_timeout_ms: int = 45_000
    slow_mo_ms: int = 0
    min_delay_ms: int = 1000
    max_delay_ms: int = 3000

    # Proxy rotation — set via env var or .env file.
    # Format: "http://user:pass@host:port" or "socks5://host:port"
    # Comma-separated list for rotation.
    proxy_list: str = ""

    # Scheduled search interval in minutes (0 = disabled).
    schedule_interval_min: int = 0


settings = Settings()


def get_proxy_list() -> List[str]:
    items: List[str] = []

    raw = settings.proxy_list.strip()
    if raw:
        items.extend(p.strip() for p in raw.split(",") if p.strip())

    # Optional file-based proxy list: data/proxies.txt
    # One proxy per line, same format as env var entries.
    path = Path("data/proxies.txt")
    if path.exists():
        try:
            for line in path.read_text(encoding="utf-8").splitlines():
                line2 = line.strip()
                if not line2 or line2.startswith("#"):
                    continue
                items.append(line2)
        except Exception:
            pass

    seen = set()
    out: List[str] = []
    for p in items:
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out
