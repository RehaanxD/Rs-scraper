from __future__ import annotations

import asyncio
import sys

from fastapi import FastAPI
from fastapi.responses import HTMLResponse

from backend.app.api.routes import router as api_router
from backend.app.core.settings import settings
from backend.app.db.init import init_db


if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

app = FastAPI(title="R Scrapper", version="0.3.0")


@app.on_event("startup")
async def _startup() -> None:
    await init_db()


@app.get("/", response_class=HTMLResponse)
async def index() -> str:
    return HTML_UI


app.include_router(api_router, prefix="/api")


def run() -> None:
    import uvicorn
    uvicorn.run(
        "backend.app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.reload,
        log_level=settings.log_level,
    )


if __name__ == "__main__":
    run()


# ── HTML UI ──────────────────────────────────────────────────────
HTML_UI = r"""
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>R Scrapper</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:ui-sans-serif,system-ui,"Segoe UI",Roboto,Arial;max-width:1100px;margin:0 auto;padding:20px 16px;background:#f8fafc;color:#0f172a}
    h1{font-size:1.6rem;margin-bottom:2px}
    .sub{color:#64748b;font-size:.88rem;margin-bottom:16px}
    .tabs{display:flex;gap:0;border-bottom:2px solid #e2e8f0;margin-bottom:0}
    .tab{padding:10px 18px;cursor:pointer;font-weight:600;font-size:.88rem;color:#64748b;border-bottom:3px solid transparent;transition:.15s}
    .tab:hover{color:#0f172a}
    .tab.active{color:#0f172a;border-bottom-color:#0f172a}
    .panel{display:none;padding:16px 0}
    .panel.active{display:block}
    .card{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:18px;margin:10px 0;box-shadow:0 1px 2px rgba(0,0,0,.04)}
    label{display:block;margin:8px 0 4px;font-weight:600;font-size:.85rem;color:#334155}
    input,select{width:100%;padding:9px 12px;border:1px solid #cbd5e1;border-radius:8px;font-size:.88rem}
    input[type=checkbox]{width:auto}
    .chk{display:flex;align-items:center;gap:8px;margin:8px 0;font-size:.85rem;color:#475569;font-weight:500}
    button{padding:9px 18px;border-radius:8px;border:none;background:#0f172a;color:white;cursor:pointer;font-weight:600;font-size:.85rem}
    button:hover{background:#1e293b}
    button:disabled{opacity:.5;cursor:not-allowed}
    .btn-o{background:#fff;color:#0f172a;border:1px solid #cbd5e1}
    .btn-o:hover{background:#f1f5f9}
    .btn-s{background:#059669;color:white}
    .btn-s:hover{background:#047857}
    .btn-d{background:#dc2626;color:white;font-size:.78rem;padding:6px 12px}
    .btn-d:hover{background:#b91c1c}
    pre{white-space:pre-wrap;background:#0f172a;color:#e2e8f0;padding:14px;border-radius:10px;overflow:auto;font-size:.78rem;max-height:400px}
    .row{display:flex;gap:10px;flex-wrap:wrap}
    .row>div{flex:1;min-width:180px}
    .muted{color:#64748b;font-size:.82rem}
    a{color:#0f172a}
    .badge{display:inline-block;padding:2px 9px;border-radius:20px;font-size:.72rem;font-weight:700;margin-right:4px}
    .bg{background:#d1fae5;color:#065f46}
    .br{background:#fee2e2;color:#991b1b}
    .bb{background:#dbeafe;color:#1e40af}
    .by{background:#fef3c7;color:#92400e}
    .bp{background:#ede9fe;color:#5b21b6}
    .stats{display:flex;gap:12px;flex-wrap:wrap;margin:12px 0}
    .stat{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 16px;text-align:center;min-width:90px;flex:1}
    .stat-n{font-size:1.5rem;font-weight:800}
    .stat-l{font-size:.72rem;color:#64748b;margin-top:2px}
    .lc{background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:12px;margin:6px 0}
    .lc h4{margin:0 0 5px;font-size:.92rem}
    .lc .info{font-size:.8rem;color:#334155;line-height:1.7}
    .lc .info span{margin-right:12px}
    .score-bar{display:inline-block;width:40px;height:8px;border-radius:4px;background:#e2e8f0;margin-right:6px;vertical-align:middle}
    .score-fill{height:100%;border-radius:4px}
    .flex-b{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px}
  </style>
</head>
<body>
  <h1>R Scrapper</h1>
  <p class="sub">Local lead finder with Maps, Web Search, site audit, lead scoring, and scheduled searches.</p>

  <div class="tabs">
    <div class="tab active" data-tab="maps">Maps</div>
    <div class="tab" data-tab="web">Web Search</div>
    <div class="tab" data-tab="leads">Leads</div>
    <div class="tab" data-tab="schedule">Schedules</div>
    <div class="tab" data-tab="dash">Dashboard</div>
  </div>

  <!-- ===== MAPS ===== -->
  <div class="panel active" id="panel-maps">
    <div class="card">
      <h3>Google Maps Search</h3>
      <p class="muted">Finds businesses, extracts phone/website/rating. Audits websites for quality. Deep-crawls for emails.</p>
      <label>Search query</label>
      <input id="m_q" placeholder='e.g. "car rental Dubai" or "plumber Manchester"'/>
      <div class="row" style="margin-top:6px">
        <div><label>Max results</label><input id="m_max" type="number" value="20" min="1" max="100"/></div>
        <div><label>Tag</label><input id="m_tag" placeholder="e.g. car-rentals"/></div>
      </div>
      <label class="chk"><input id="m_nw" type="checkbox" checked/> Only save businesses WITHOUT their own website</label>
      <div class="flex-b"><button id="m_run">Search Maps</button><span class="muted" id="m_st"></span></div>
    </div>
    <div id="m_res"></div>
  </div>

  <!-- ===== WEB ===== -->
  <div class="panel" id="panel-web">
    <div class="card">
      <h3>Web Search</h3>
      <div class="row">
        <div><label>Engine</label><select id="w_eng"><option value="google">Google</option><option value="bing" selected>Bing</option><option value="ddg">DuckDuckGo</option></select></div>
        <div><label>Max results</label><input id="w_max" type="number" value="20" min="1" max="200"/></div>
      </div>
      <label class="chk"><input id="w_nw" type="checkbox"/> Only keep leads without a website</label>
      <label>Query</label><input id="w_q" placeholder='e.g. "plumber manchester phone"'/>
      <label>Location hint</label><input id="w_loc" placeholder="e.g. Manchester, UK"/>
      <label>Tag</label><input id="w_tag"/>
      <div class="flex-b"><button id="w_run">Run Web Search</button><span class="muted" id="w_st"></span></div>
    </div>
    <div id="w_res"></div>
  </div>

  <!-- ===== LEADS ===== -->
  <div class="panel" id="panel-leads">
    <div class="card">
      <h3>Saved Leads</h3>
      <div class="row">
        <div><label>Source</label><select id="l_src"><option value="">All</option><option value="google_maps">Maps</option><option value="google">Google</option><option value="bing">Bing</option><option value="ddg">DDG</option></select></div>
        <div><label>Min Score</label><input id="l_ms" type="number" placeholder="0" min="0" max="100"/></div>
        <div><label>Grade</label><select id="l_gr"><option value="">All</option><option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option></select></div>
        <div><label>Tag</label><input id="l_tag"/></div>
      </div>
      <label class="chk"><input id="l_nw" type="checkbox"/> No website only</label>
      <div class="flex-b">
        <button id="l_load">Load</button>
        <button class="btn-o" id="l_csv">CSV</button>
        <button class="btn-s" id="l_xlsx">Excel</button>
        <button class="btn-o" id="l_json">JSON</button>
      </div>
    </div>
    <div id="l_res"></div>
  </div>

  <!-- ===== SCHEDULE ===== -->
  <div class="panel" id="panel-schedule">
    <div class="card">
      <h3>Scheduled Searches</h3>
      <p class="muted">Create recurring searches that auto-run on a timer. Use "Run Now" to trigger manually.</p>
      <div class="row">
        <div><label>Type</label><select id="s_type"><option value="maps">Maps</option><option value="web">Web</option></select></div>
        <div><label>Interval (min)</label><input id="s_int" type="number" value="60" min="5"/></div>
      </div>
      <label>Query</label><input id="s_q" placeholder='e.g. "plumber London"'/>
      <div class="row"><div><label>Max results</label><input id="s_max" type="number" value="20"/></div><div><label>Tag</label><input id="s_tag"/></div></div>
      <label class="chk"><input id="s_nw" type="checkbox" checked/> Only no-website leads</label>
      <div class="flex-b"><button id="s_add">Add Schedule</button></div>
    </div>
    <div id="s_list"></div>
  </div>

  <!-- ===== DASHBOARD ===== -->
  <div class="panel" id="panel-dash">
    <div class="card"><h3>Dashboard</h3><p class="muted">Overview of all your leads.</p><button id="d_load">Refresh</button></div>
    <div id="d_stats"></div>
  </div>

  <!-- RAW OUTPUT -->
  <div class="card" style="margin-top:12px"><h3 style="font-size:.9rem">Raw Output</h3><pre id="out">Ready.</pre></div>

<script>
// Tab switching
document.querySelectorAll('.tab').forEach(t=>{
  t.addEventListener('click',()=>{
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(x=>x.classList.remove('active'));
    t.classList.add('active');
    document.getElementById('panel-'+t.dataset.tab).classList.add('active');
  });
});
const out=document.getElementById('out');

function renderStats(d){
  return `<div class="stats">
    <div class="stat"><div class="stat-n">${d.found||0}</div><div class="stat-l">Found</div></div>
    <div class="stat"><div class="stat-n">${d.saved||0}</div><div class="stat-l">Saved</div></div>
    ${d.skipped_has_website?`<div class="stat"><div class="stat-n">${d.skipped_has_website}</div><div class="stat-l">Skipped</div></div>`:''}
  </div>`;
}

function gradeClass(g){return g==='A'?'bg':g==='B'?'bb':g==='C'?'by':'br';}

function renderLead(l){
  const name=l.maps_name||l.title||'(untitled)';
  const ph=l.phones_csv||'';
  const em=l.emails_csv||'';
  const wa=l.whatsapp_csv||'';
  const addr=l.maps_address||l.snippet||'';
  const cat=l.maps_category||'';
  const rating=l.maps_rating?l.maps_rating+'/5':'';
  const reviews=l.maps_review_count||'';
  const web=l.maps_website||l.domain||'';
  const hasWeb=l.has_website_signal;
  const webB=hasWeb===false?'<span class="badge br">NO WEBSITE</span>':hasWeb===true?'<span class="badge bg">Has Website</span>':'';
  const src=`<span class="badge bb">${l.source_engine}</span>`;
  const grade=l.lead_grade?`<span class="badge ${gradeClass(l.lead_grade)}">${l.lead_grade}</span>`:'';
  const score=l.lead_score||0;
  const scoreColor=score>=80?'#059669':score>=60?'#2563eb':score>=40?'#d97706':'#dc2626';
  const scoreBar=`<span class="score-bar"><span class="score-fill" style="width:${score}%;background:${scoreColor}"></span></span>${score}`;
  const social=l.social_profiles_csv||'';
  const ssl=l.site_has_ssl===true?'<span class="badge bg">SSL</span>':l.site_has_ssl===false?'<span class="badge br">No SSL</span>':'';
  const qual=l.site_quality_score?`<b>Quality:</b> ${l.site_quality_score}/100`:'';

  return `<div class="lc">
    <h4>${src} ${grade} ${webB} ${ssl} ${name}</h4>
    <div class="info">
      <span><b>Score:</b> ${scoreBar}</span>
      ${ph?`<span><b>Phone:</b> ${ph}</span>`:''}
      ${em?`<span><b>Email:</b> ${em}</span>`:''}
      ${wa?`<span><b>WhatsApp:</b> ${wa}</span>`:''}
      ${addr?`<br><b>Address:</b> ${addr}`:''}
      ${cat?`<span><b>Category:</b> ${cat}</span>`:''}
      ${rating?`<span><b>Rating:</b> ${rating} (${reviews} reviews)</span>`:''}
      ${web?`<br><b>Web:</b> <a href="${web}" target="_blank">${web.substring(0,60)}</a>`:''}
      ${social?`<br><b>Social:</b> ${social.substring(0,100)}`:''}
      ${qual?`<span>${qual}</span>`:''}
    </div>
  </div>`;
}

// MAPS
document.getElementById('m_run').addEventListener('click',async()=>{
  const btn=document.getElementById('m_run');btn.disabled=true;
  document.getElementById('m_st').textContent='Searching Maps... (1-3 min)';out.textContent='Running...';
  try{
    const b={query:document.getElementById('m_q').value,max_results:+document.getElementById('m_max').value||20,
      tag:document.getElementById('m_tag').value||null,only_no_website:document.getElementById('m_nw').checked};
    const r=await fetch('/api/maps-search',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});
    const j=await r.json();out.textContent=JSON.stringify(j,null,2);
    let h=renderStats(j);(j.leads||[]).forEach(l=>{h+=renderLead(l);});
    document.getElementById('m_res').innerHTML=h;
    document.getElementById('m_st').textContent=`Done! ${j.saved} leads saved.`;
  }catch(e){out.textContent=String(e);document.getElementById('m_st').textContent='Error.';}
  finally{btn.disabled=false;}
});

// WEB
document.getElementById('w_run').addEventListener('click',async()=>{
  const btn=document.getElementById('w_run');btn.disabled=true;
  document.getElementById('w_st').textContent='Searching...';out.textContent='Running...';
  try{
    const b={engine:document.getElementById('w_eng').value,query:document.getElementById('w_q').value,
      location_hint:document.getElementById('w_loc').value||null,max_results:+document.getElementById('w_max').value||20,
      tag:document.getElementById('w_tag').value||null,only_no_website:document.getElementById('w_nw').checked};
    const r=await fetch('/api/search',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});
    const j=await r.json();out.textContent=JSON.stringify(j,null,2);
    let h=renderStats(j);(j.leads||[]).forEach(l=>{h+=renderLead(l);});
    document.getElementById('w_res').innerHTML=h;
    document.getElementById('w_st').textContent=`Done! ${j.saved} leads.`;
  }catch(e){out.textContent=String(e);}finally{btn.disabled=false;}
});

// LEADS
document.getElementById('l_load').addEventListener('click',async()=>{
  let u='/api/leads?limit=200';
  const src=document.getElementById('l_src').value;if(src)u+='&source='+src;
  const tag=document.getElementById('l_tag').value;if(tag)u+='&tag='+encodeURIComponent(tag);
  if(document.getElementById('l_nw').checked)u+='&no_website_only=true';
  const ms=document.getElementById('l_ms').value;if(ms)u+='&min_score='+ms;
  const gr=document.getElementById('l_gr').value;if(gr)u+='&grade='+gr;
  const r=await fetch(u);const leads=await r.json();out.textContent=JSON.stringify(leads,null,2);
  let h=`<div class="stats"><div class="stat"><div class="stat-n">${leads.length}</div><div class="stat-l">Leads</div></div></div>`;
  leads.forEach(l=>{h+=renderLead(l);});document.getElementById('l_res').innerHTML=h;
});
function expUrl(){
  let u='';const src=document.getElementById('l_src').value;if(src)u+='source='+src+'&';
  const tag=document.getElementById('l_tag').value;if(tag)u+='tag='+encodeURIComponent(tag)+'&';
  if(document.getElementById('l_nw').checked)u+='no_website_only=true&';return u;
}
document.getElementById('l_csv').addEventListener('click',()=>window.open('/api/export.csv?'+expUrl(),'_blank'));
document.getElementById('l_xlsx').addEventListener('click',()=>window.open('/api/export.xlsx?'+expUrl(),'_blank'));
document.getElementById('l_json').addEventListener('click',()=>window.open('/api/leads?limit=500&'+expUrl(),'_blank'));

// SCHEDULES
async function loadSchedules(){
  const r=await fetch('/api/schedules');const list=await r.json();
  let h='';for(const s of list){
    h+=`<div class="lc"><h4><span class="badge bb">${s.search_type}</span> ${s.query}</h4>
    <div class="info"><b>Every:</b> ${s.interval_minutes}min | <b>Tag:</b> ${s.tag||'(none)'} | <b>Runs:</b> ${s.total_runs} | <b>Leads:</b> ${s.total_leads_found}
    ${s.last_run_at?'| <b>Last:</b> '+s.last_run_at.substring(0,16):''}</div>
    <div class="flex-b"><button class="btn-s" onclick="runSched(${s.id})">Run Now</button>
    <button class="btn-d" onclick="delSched(${s.id})">Delete</button></div></div>`;
  }
  document.getElementById('s_list').innerHTML=h||'<p class="muted" style="margin:12px 0">No scheduled searches yet.</p>';
}
document.getElementById('s_add').addEventListener('click',async()=>{
  const b={search_type:document.getElementById('s_type').value,query:document.getElementById('s_q').value,
    max_results:+document.getElementById('s_max').value||20,tag:document.getElementById('s_tag').value||null,
    only_no_website:document.getElementById('s_nw').checked,interval_minutes:+document.getElementById('s_int').value||60};
  await fetch('/api/schedules',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});
  loadSchedules();
});
window.runSched=async(id)=>{
  out.textContent='Running scheduled search...';
  const r=await fetch('/api/schedules/'+id+'/run',{method:'POST'});
  const j=await r.json();out.textContent=JSON.stringify(j,null,2);loadSchedules();
};
window.delSched=async(id)=>{
  await fetch('/api/schedules/'+id,{method:'DELETE'});loadSchedules();
};

// DASHBOARD
document.getElementById('d_load').addEventListener('click',async()=>{
  const r=await fetch('/api/stats');const s=await r.json();out.textContent=JSON.stringify(s,null,2);
  const grades=s.grades||{};const sources=s.sources||{};const tags=s.tags||{};
  let h=`<div class="stats">
    <div class="stat"><div class="stat-n">${s.total_leads}</div><div class="stat-l">Total Leads</div></div>
    <div class="stat"><div class="stat-n">${s.no_website}</div><div class="stat-l">No Website</div></div>
    <div class="stat"><div class="stat-n">${s.has_website}</div><div class="stat-l">Has Website</div></div>
    <div class="stat"><div class="stat-n">${s.with_phone}</div><div class="stat-l">With Phone</div></div>
    <div class="stat"><div class="stat-n">${s.with_email}</div><div class="stat-l">With Email</div></div>
    <div class="stat"><div class="stat-n">${s.avg_lead_score}</div><div class="stat-l">Avg Score</div></div>
  </div>`;

  // Grade bars
  const maxG=Math.max(grades.A||0,grades.B||0,grades.C||0,grades.D||0,1);
  h+=`<div class="card"><h4>Lead Grades</h4><div style="margin-top:10px">`;
  for(const [g,c] of [['A',grades.A||0],['B',grades.B||0],['C',grades.C||0],['D',grades.D||0]]){
    const color=g==='A'?'#059669':g==='B'?'#2563eb':g==='C'?'#d97706':'#dc2626';
    const pct=Math.round(c/maxG*100);
    h+=`<div style="display:flex;align-items:center;gap:8px;margin:6px 0">
      <span style="width:20px;font-weight:700;color:${color}">${g}</span>
      <div style="flex:1;height:24px;background:#f1f5f9;border-radius:6px;overflow:hidden">
        <div style="width:${pct}%;height:100%;background:${color};border-radius:6px;display:flex;align-items:center;padding-left:8px;color:#fff;font-size:.75rem;font-weight:700">${c}</div>
      </div>
    </div>`;
  }
  h+=`</div></div>`;

  // Sources
  h+=`<div class="card"><h4>Sources</h4><div class="stats">`;
  for(const [src,cnt] of Object.entries(sources)){
    h+=`<div class="stat"><div class="stat-n">${cnt}</div><div class="stat-l">${src}</div></div>`;
  }
  h+=`</div></div>`;

  // Tags
  if(Object.keys(tags).length){
    h+=`<div class="card"><h4>Tags</h4><div class="stats">`;
    for(const [t,cnt] of Object.entries(tags)){
      h+=`<div class="stat"><div class="stat-n">${cnt}</div><div class="stat-l">${t}</div></div>`;
    }
    h+=`</div></div>`;
  }

  document.getElementById('d_stats').innerHTML=h;
});

// Auto-load schedules when tab opens
document.querySelector('[data-tab="schedule"]').addEventListener('click',loadSchedules);
document.querySelector('[data-tab="dash"]').addEventListener('click',()=>document.getElementById('d_load').click());
</script>
</body>
</html>
"""
