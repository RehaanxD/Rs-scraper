from __future__ import annotations

from sqlmodel import SQLModel
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.ext.asyncio import create_async_engine

from backend.app.core.settings import settings


def _db_url() -> str:
    # aiosqlite path; relative path ok
    return f"sqlite+aiosqlite:///{settings.db_path}"


engine = create_async_engine(_db_url(), echo=False, future=True)


async def init_models() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)


def session_factory() -> AsyncSession:
    return AsyncSession(engine)

