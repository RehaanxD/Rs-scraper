from __future__ import annotations

from backend.app.db.models import Lead, ScheduledSearch  # noqa: F401 - ensure tables are registered
from backend.app.db.session import init_models


async def init_db() -> None:
    await init_models()
