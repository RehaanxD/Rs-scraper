from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlmodel import Field, SQLModel


class Lead(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)

    created_at: datetime = Field(default_factory=datetime.utcnow, index=True)
    updated_at: datetime = Field(default_factory=datetime.utcnow, index=True)

    source_engine: str = Field(index=True)
    search_query: str = Field(index=True)
    tag: Optional[str] = Field(default=None, index=True)

    title: Optional[str] = None
    url: str = Field(index=True, unique=True)
    domain: Optional[str] = Field(default=None, index=True)

    snippet: Optional[str] = None

    emails_csv: Optional[str] = None
    phones_csv: Optional[str] = None

    contact_urls_csv: Optional[str] = None

    has_website_signal: Optional[bool] = None
    automation_intent_score: int = 0
    notes: Optional[str] = None

    # Google Maps fields
    maps_name: Optional[str] = Field(default=None, index=True)
    maps_address: Optional[str] = None
    maps_rating: Optional[float] = None
    maps_review_count: Optional[int] = None
    maps_category: Optional[str] = None
    maps_website: Optional[str] = None
    maps_place_url: Optional[str] = None

    # Website quality audit fields
    site_has_ssl: Optional[bool] = None
    site_is_mobile_friendly: Optional[bool] = None
    site_load_time_ms: Optional[int] = None
    site_quality_score: Optional[int] = None

    # Social profiles (JSON-like csv: "facebook=url,instagram=url")
    social_profiles_csv: Optional[str] = None
    whatsapp_csv: Optional[str] = None

    # Lead scoring
    lead_score: int = Field(default=0, index=True)
    lead_grade: Optional[str] = Field(default=None, index=True)


class ScheduledSearch(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    search_type: str = "maps"
    query: str = ""
    max_results: int = 20
    tag: Optional[str] = None
    only_no_website: bool = True
    interval_minutes: int = 60
    last_run_at: Optional[datetime] = None
    is_active: bool = True
    total_runs: int = 0
    total_leads_found: int = 0
