from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import List, Optional
from urllib.parse import quote_plus

from playwright.async_api import Page

from backend.app.scrape.human import human_delay, human_scroll, random_mouse_movement
from backend.app.scrape.utils import extract_emails, extract_phones

log = logging.getLogger("scraper.maps")


@dataclass
class MapsListing:
    name: str = ""
    address: str = ""
    phone: str = ""
    website: str = ""
    rating: Optional[float] = None
    review_count: Optional[int] = None
    category: str = ""
    place_url: str = ""
    emails: List[str] = field(default_factory=list)
    has_website: bool = False


async def _scroll_maps_results(page: Page, target_count: int) -> None:
    feed = page.locator("div[role='feed']")
    if await feed.count() == 0:
        feed = page.locator("div.m6QErb[aria-label]")
    if await feed.count() == 0:
        return

    for _ in range(40):
        items = page.locator("a.hfpxzc")
        current = await items.count()
        if current >= target_count:
            break

        end_marker = page.locator("span.HlvSq, p.fontBodyMedium:has-text('end of list')")
        if await end_marker.count() > 0:
            break

        await feed.first.evaluate("el => el.scrollTop = el.scrollHeight")
        await human_delay(800, 1500)


async def _handle_maps_consent(page: Page) -> None:
    from backend.app.scrape.human import dismiss_google_consent

    maps_consent = [
        "button[aria-label='Accept all']",
        "button:has-text('Accept all')",
        "button:has-text('I agree')",
        "form[action*='consent'] button",
        "button.VfPpkd-LgbsSe[jsname]",
    ]
    for sel in maps_consent:
        try:
            btn = page.locator(sel).first
            if await btn.is_visible(timeout=800):
                await btn.click(timeout=3000)
                await human_delay(1000, 2000)
                return
        except Exception:
            continue

    await dismiss_google_consent(page)


# JavaScript to extract ALL listing data from the search results sidebar
# in a single pass, without needing to click each listing.
BULK_EXTRACT_JS = """
() => {
    const results = [];

    // Each listing card is an <a> with class "hfpxzc".
    const cards = document.querySelectorAll('a.hfpxzc');

    for (const card of cards) {
        const item = {
            name: '',
            phone: '',
            address: '',
            website: '',
            rating: null,
            review_count: null,
            category: '',
            place_url: card.href || '',
            has_website: false,
        };

        // Name from aria-label.
        item.name = (card.getAttribute('aria-label') || '').split(',')[0].trim();

        // The card's parent container has all the visible info.
        // Walk up to the wrapping div.
        let container = card.closest('div') || card.parentElement;
        // Actually, the info is in sibling elements after the <a>.
        // In Maps, the structure is roughly:
        //   <div> (the listing wrapper)
        //     <a class="hfpxzc"> (clickable card)
        //     <div> (info area with rating, phone, address, etc.)
        // Let's find the nearest parent that contains all the text.
        let wrapper = card.parentElement;
        while (wrapper && !wrapper.querySelector('.fontBodyMedium')) {
            wrapper = wrapper.parentElement;
            if (wrapper === document.body) { wrapper = card.parentElement; break; }
        }

        const wrapperText = wrapper ? wrapper.textContent : '';

        // Rating: look for a star rating pattern.
        const ratingMatch = wrapperText.match(/(\\d[.,]\\d)\\s/);
        if (ratingMatch) {
            item.rating = parseFloat(ratingMatch[1].replace(',', '.'));
        }

        // Review count: number in parentheses like (429) or (9,855).
        const reviewMatch = wrapperText.match(/\\(([\\d,.]+)\\)/);
        if (reviewMatch) {
            item.review_count = parseInt(reviewMatch[1].replace(/[,.]/g, ''));
        }

        // Phone: require + prefix, 0 prefix, or (area code) to avoid
        // matching things like "24 7 365" from business names.
        const phonePatterns = wrapperText.match(
            /(?:\\+\\d{1,3}[\\s-]?\\d[\\d\\s-]{6,14}\\d)|(?:0\\d[\\d\\s-]{7,14}\\d)|(?:\\(\\d{2,5}\\)[\\s-]?\\d[\\d\\s-]{5,12}\\d)/g
        );
        if (phonePatterns) {
            for (const p of phonePatterns) {
                const digits = p.replace(/\\D/g, '');
                if (digits.length >= 7 && digits.length <= 15) {
                    item.phone = p.trim();
                    break;
                }
            }
        }

        // Website link: look for <a> elements within the wrapper that point
        // to external sites (not google.com).
        if (wrapper) {
            const links = wrapper.querySelectorAll('a[href]');
            for (const link of links) {
                const href = link.href || '';
                if (href && !href.includes('google.com') && !href.includes('gstatic.com')
                    && href.startsWith('http') && !href.includes('maps/')
                    && !href.includes('search?')) {
                    item.website = href;
                    item.has_website = true;
                    break;
                }
            }
        }

        // Category: typically in a span between the rating and address.
        // It's the text that says "Car rental agency", "Plumber", etc.
        if (wrapper) {
            const spans = wrapper.querySelectorAll('span');
            for (const span of spans) {
                const text = span.textContent.trim();
                // Categories are typically short, not a number, and don't
                // contain phone patterns or addresses.
                if (text.length > 3 && text.length < 50
                    && !/\\d{3}/.test(text)
                    && !text.includes('(')
                    && !/^\\d/.test(text)
                    && text !== item.name) {
                    // This could be category, address, or other info.
                    // Category tends to come before address.
                    if (!item.category) {
                        item.category = text;
                    }
                }
            }
        }

        if (item.name) {
            results.push(item);
        }
    }

    return results;
}
"""

# Second pass: click into each listing to get phone/address/website
# from the detail panel (more reliable for data-item-id approach).
DETAIL_CLICK_EXTRACT_JS = """
() => {
    const info = {phone: '', address: '', website: '', category: '',
                  rating: null, review_count: null};

    // The detail panel contains elements with data-item-id or
    // specific aria-labels. These render after clicking a listing.
    // Scan all elements with text that looks like phone/address.
    const allText = document.body.innerText || '';
    const lines = allText.split('\\n').map(l => l.trim()).filter(l => l);

    // Look for phone number (digits with spaces/dashes, 7+ chars).
    for (const line of lines) {
        if (!info.phone) {
            const phoneMatch = line.match(/^[\\+]?[\\d][\\d\\s\\-\\(\\)]{6,16}$/);
            if (phoneMatch) {
                const digits = phoneMatch[0].replace(/\\D/g, '');
                if (digits.length >= 7 && digits.length <= 15) {
                    info.phone = phoneMatch[0].trim();
                }
            }
        }
    }

    return info;
}
"""


async def scrape_google_maps(
    page: Page, query: str, max_results: int = 20
) -> List[MapsListing]:
    url = f"https://www.google.com/maps/search/{quote_plus(query)}?hl=en"
    await page.goto(url, wait_until="domcontentloaded")
    await human_delay(2000, 4000)
    await random_mouse_movement(page)

    for _ in range(3):
        await _handle_maps_consent(page)
        await human_delay(500, 1000)

    # Wait for results feed.
    feed_found = False
    for attempt in range(3):
        try:
            await page.wait_for_selector(
                "div[role='feed'], div.m6QErb, div.Nv2PK",
                timeout=10_000,
            )
            feed_found = True
            break
        except Exception:
            print(f"[MAPS] Feed not found (attempt {attempt+1}/3)")
            await _handle_maps_consent(page)
            await human_delay(1500, 3000)
            if attempt == 1:
                await page.reload(wait_until="domcontentloaded")
                await human_delay(2000, 4000)
                await _handle_maps_consent(page)

    if not feed_found:
        print(f"[MAPS] Feed not found after retries. URL={page.url}")
        return []

    await human_delay(1000, 2000)
    print(f"[MAPS] Feed found. URL={page.url}")

    await _scroll_maps_results(page, max_results)
    await human_delay(1000, 2000)

    # Phase 1: bulk-extract from the search results sidebar.
    raw_results = await page.evaluate(BULK_EXTRACT_JS)
    print(f"[MAPS] Bulk extracted {len(raw_results)} listings from sidebar")

    listings: List[MapsListing] = []

    for i, r in enumerate(raw_results[:max_results]):
        listing = MapsListing(
            name=r.get("name", ""),
            phone=r.get("phone", ""),
            address=r.get("address", ""),
            website=r.get("website", ""),
            rating=r.get("rating"),
            review_count=r.get("review_count"),
            category=r.get("category", ""),
            place_url=r.get("place_url", ""),
            emails=[],
            has_website=r.get("has_website", False),
        )

        try:
            print(
                f"[MAPS] [{i+1}] {listing.name[:40]} | "
                f"phone={listing.phone} | "
                f"rating={listing.rating} | "
                f"web={'YES' if listing.has_website else 'no'}"
            )
        except Exception:
            print(f"[MAPS] [{i+1}] extracted")

        if listing.name:
            listings.append(listing)

    # Phase 2: for listings missing phone/website, click in to get details.
    CARD_SEL = "a.hfpxzc"
    for i, listing in enumerate(listings):
        if listing.phone and listing.website:
            continue

        try:
            cards = page.locator(CARD_SEL)
            if i >= await cards.count():
                break

            card = cards.nth(i)
            try:
                await card.scroll_into_view_if_needed(timeout=5000)
            except Exception:
                pass
            await human_delay(300, 600)

            url_before = page.url
            await card.click(timeout=10_000)

            for _w in range(15):
                await human_delay(400, 600)
                if page.url != url_before:
                    break

            await human_delay(2000, 4000)

            # Extract phone from detail panel if missing.
            if not listing.phone:
                try:
                    detail = await page.evaluate(DETAIL_CLICK_EXTRACT_JS)
                    if detail.get("phone"):
                        listing.phone = detail["phone"]
                        print(f"[MAPS] [{i+1}] Got phone from detail: {listing.phone}")
                except Exception:
                    pass

            # Extract website from detail panel if missing.
            if not listing.website:
                try:
                    web_el = page.locator("a[data-item-id='authority'], a[aria-label*='ebsite' i], a[aria-label*='موقع' i]")
                    if await web_el.count() > 0:
                        href = (await web_el.first.get_attribute("href")) or ""
                        if href.startswith("http"):
                            listing.website = href
                            listing.has_website = True
                            print(f"[MAPS] [{i+1}] Got website from detail: {listing.website[:50]}")
                except Exception:
                    pass

            # Navigate back.
            back_btn = page.locator(
                "button[aria-label='Back'], button[aria-label*='back' i], "
                "button[aria-label*='رجوع'], button.hYBOP"
            )
            if await back_btn.count() > 0:
                await back_btn.first.click(timeout=5000)
            else:
                await page.go_back(wait_until="domcontentloaded")
            await human_delay(1000, 2000)

            try:
                await page.wait_for_selector("div[role='feed'], div.m6QErb", timeout=8000)
            except Exception:
                pass

        except Exception as exc:
            try:
                print(f"[MAPS] [{i+1}] Detail click error: {exc}")
            except Exception:
                pass
            try:
                await page.go_back(wait_until="domcontentloaded")
                await human_delay(1000, 2000)
            except Exception:
                pass

    return listings
