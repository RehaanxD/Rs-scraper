from __future__ import annotations

import asyncio
import random
from typing import Optional

from playwright.async_api import Page

from backend.app.core.settings import settings


async def human_delay(min_ms: int = 400, max_ms: int = 1800) -> None:
    ms = random.randint(min_ms, max_ms)
    await asyncio.sleep(ms / 1000.0)


async def human_type(page: Page, selector: str, text: str) -> None:
    loc = page.locator(selector)
    await loc.first.wait_for(state="visible", timeout=settings.nav_timeout_ms)
    await loc.first.click()
    await human_delay(200, 500)

    for char in text:
        await page.keyboard.type(char, delay=random.randint(35, 120))
        if random.random() < 0.03:
            await human_delay(150, 400)


async def human_scroll(page: Page, times: int = 1) -> None:
    for _ in range(times):
        dx = random.randint(-5, 5)
        dy = random.randint(200, 600)
        await page.mouse.wheel(dx, dy)
        await human_delay(300, 800)


async def random_mouse_movement(page: Page) -> None:
    vp = page.viewport_size or {"width": 1280, "height": 800}
    for _ in range(random.randint(2, 5)):
        x = random.randint(100, vp["width"] - 100)
        y = random.randint(100, vp["height"] - 100)
        await page.mouse.move(x, y, steps=random.randint(5, 15))
        await human_delay(80, 250)


async def dismiss_google_consent(page: Page) -> None:
    from backend.app.scrape.stealth import GOOGLE_CONSENT_SELECTORS

    for sel in GOOGLE_CONSENT_SELECTORS:
        try:
            btn = page.locator(sel).first
            if await btn.is_visible(timeout=600):
                await btn.click(timeout=3000)
                await human_delay(500, 1200)
                return
        except Exception:
            continue


async def check_and_handle_captcha(page: Page) -> bool:
    from backend.app.scrape.stealth import is_captcha_page

    try:
        url = page.url
        text = await page.inner_text("body", timeout=3000)
    except Exception:
        return False

    if is_captcha_page(url, text):
        await human_delay(3000, 6000)
        try:
            await page.reload(wait_until="domcontentloaded")
            await human_delay(2000, 4000)
            url2 = page.url
            text2 = await page.inner_text("body", timeout=3000)
            return is_captcha_page(url2, text2)
        except Exception:
            return True
    return False
