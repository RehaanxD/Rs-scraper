from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlmodel import or_, select

from backend.app.db.models import Lead
from backend.app.db.session import session_factory
from backend.app.scrape.browsers import browser_page
from backend.app.scrape.maps_scraper import scrape_google_maps
from backend.app.scrape.page_scan import scan_page_for_lead
from backend.app.scrape.search_engines import search_engine
from backend.app.scrape.site_auditor import SiteAudit, audit_website
from backend.app.scrape.utils import domain_from_url, looks_like_directory_or_social_only, uniq_keep_order

log = logging.getLogger("scraper.pipeline")


def _csv(items: List[str]) -> Optional[str]:
    items2 = uniq_keep_order(items)
    return ",".join(items2) if items2 else None


def compute_lead_score(lead: Lead) -> tuple[int, str]:
    """Compute a 0-100 lead score. Higher = better lead for selling web dev."""
    score = 50

    if lead.has_website_signal is False:
        score += 30
    elif lead.has_website_signal is True:
        score -= 10

    if lead.site_quality_score is not None:
        if lead.site_quality_score < 30:
            score += 20
        elif lead.site_quality_score < 50:
            score += 10
        elif lead.site_quality_score > 80:
            score -= 15

    if lead.site_has_ssl is False:
        score += 10

    if lead.site_is_mobile_friendly is False:
        score += 10

    if lead.phones_csv:
        score += 5
    if lead.emails_csv:
        score += 5

    if not lead.social_profiles_csv:
        score += 5

    if lead.maps_rating and lead.maps_rating >= 4.0:
        score += 5

    if lead.maps_review_count and lead.maps_review_count >= 50:
        score += 5

    if lead.automation_intent_score > 0:
        score += min(lead.automation_intent_score * 3, 15)

    score = max(0, min(100, score))

    if score >= 80:
        grade = "A"
    elif score >= 60:
        grade = "B"
    elif score >= 40:
        grade = "C"
    else:
        grade = "D"

    return score, grade


def _social_dict_to_csv(profiles: Dict[str, str]) -> Optional[str]:
    if not profiles:
        return None
    parts = [f"{k}={v}" for k, v in profiles.items()]
    return ",".join(parts)


async def find_duplicate_lead(
    session, *, url: str, maps_name: Optional[str] = None, domain: Optional[str] = None
) -> Optional[Lead]:
    """Find an existing lead by URL, or by maps_name + domain for cross-source dedup."""
    existing = (await session.exec(select(Lead).where(Lead.url == url))).first()
    if existing:
        return existing

    if maps_name and domain:
        existing = (
            await session.exec(
                select(Lead).where(
                    Lead.maps_name == maps_name,
                    Lead.domain == domain,
                )
            )
        ).first()
        if existing:
            return existing

    if maps_name:
        existing = (
            await session.exec(
                select(Lead).where(Lead.maps_name == maps_name)
            )
        ).first()
        if existing:
            return existing

    return None


async def upsert_lead(
    *,
    source_engine: str,
    search_query: str,
    tag: Optional[str],
    title: Optional[str],
    url: str,
    snippet: Optional[str],
    emails: List[str],
    phones: List[str],
    contact_urls: List[str],
    automation_intent_score: int,
    has_website_signal: Optional[bool],
    notes: Optional[str] = None,
    maps_name: Optional[str] = None,
    maps_address: Optional[str] = None,
    maps_rating: Optional[float] = None,
    maps_review_count: Optional[int] = None,
    maps_category: Optional[str] = None,
    maps_website: Optional[str] = None,
    maps_place_url: Optional[str] = None,
    site_audit: Optional[SiteAudit] = None,
    social_profiles: Optional[Dict[str, str]] = None,
    whatsapp_numbers: Optional[List[str]] = None,
) -> Lead:
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        raise ValueError("URL must start with http(s)://")

    async with session_factory() as session:
        existing = await find_duplicate_lead(
            session, url=url, maps_name=maps_name, domain=domain_from_url(url)
        )
        now = datetime.utcnow()

        if existing:
            existing.updated_at = now
            existing.source_engine = source_engine
            existing.search_query = search_query
            existing.tag = tag
            existing.title = title or existing.title
            existing.snippet = snippet or existing.snippet
            existing.domain = existing.domain or domain_from_url(url)

            prev_emails = (existing.emails_csv or "").split(",") if existing.emails_csv else []
            prev_phones = (existing.phones_csv or "").split(",") if existing.phones_csv else []
            prev_contacts = (
                (existing.contact_urls_csv or "").split(",") if existing.contact_urls_csv else []
            )

            existing.emails_csv = _csv([*prev_emails, *emails])
            existing.phones_csv = _csv([*prev_phones, *phones])
            existing.contact_urls_csv = _csv([*prev_contacts, *contact_urls])
            existing.automation_intent_score = max(
                existing.automation_intent_score, int(automation_intent_score)
            )
            if has_website_signal is not None:
                existing.has_website_signal = has_website_signal
            if notes:
                existing.notes = notes
            if maps_name:
                existing.maps_name = maps_name
            if maps_address:
                existing.maps_address = maps_address
            if maps_rating is not None:
                existing.maps_rating = maps_rating
            if maps_review_count is not None:
                existing.maps_review_count = maps_review_count
            if maps_category:
                existing.maps_category = maps_category
            if maps_website:
                existing.maps_website = maps_website
            if maps_place_url:
                existing.maps_place_url = maps_place_url

            if site_audit:
                existing.site_has_ssl = site_audit.has_ssl
                existing.site_is_mobile_friendly = site_audit.has_viewport_meta
                existing.site_load_time_ms = site_audit.load_time_ms
                existing.site_quality_score = site_audit.quality_score
                audit_emails = site_audit.emails or []
                audit_phones = site_audit.phones or []
                existing.emails_csv = _csv(
                    [*(existing.emails_csv or "").split(","), *audit_emails]
                    if existing.emails_csv else audit_emails
                )
                existing.phones_csv = _csv(
                    [*(existing.phones_csv or "").split(","), *audit_phones]
                    if existing.phones_csv else audit_phones
                )

            if social_profiles:
                existing.social_profiles_csv = _social_dict_to_csv(social_profiles)
            if whatsapp_numbers:
                existing.whatsapp_csv = _csv(whatsapp_numbers)

            existing.lead_score, existing.lead_grade = compute_lead_score(existing)

            session.add(existing)
            await session.commit()
            await session.refresh(existing)
            return existing

        lead = Lead(
            created_at=now,
            updated_at=now,
            source_engine=source_engine,
            search_query=search_query,
            tag=tag,
            title=title,
            url=url,
            domain=domain_from_url(url),
            snippet=snippet,
            emails_csv=_csv(emails),
            phones_csv=_csv(phones),
            contact_urls_csv=_csv(contact_urls),
            has_website_signal=has_website_signal,
            automation_intent_score=int(automation_intent_score),
            notes=notes,
            maps_name=maps_name,
            maps_address=maps_address,
            maps_rating=maps_rating,
            maps_review_count=maps_review_count,
            maps_category=maps_category,
            maps_website=maps_website,
            maps_place_url=maps_place_url,
        )

        if site_audit:
            lead.site_has_ssl = site_audit.has_ssl
            lead.site_is_mobile_friendly = site_audit.has_viewport_meta
            lead.site_load_time_ms = site_audit.load_time_ms
            lead.site_quality_score = site_audit.quality_score
            lead.emails_csv = _csv([*(emails or []), *(site_audit.emails or [])])
            lead.phones_csv = _csv([*(phones or []), *(site_audit.phones or [])])

        if social_profiles:
            lead.social_profiles_csv = _social_dict_to_csv(social_profiles)
        if whatsapp_numbers:
            lead.whatsapp_csv = _csv(whatsapp_numbers)

        lead.lead_score, lead.lead_grade = compute_lead_score(lead)

        session.add(lead)
        await session.commit()
        await session.refresh(lead)
        return lead


async def scan_single_url(url: str, engine: str, search_query: str, tag: Optional[str]) -> Dict[str, Any]:
    async with browser_page() as page:
        scan = await scan_page_for_lead(page, url)
    lead = await upsert_lead(
        source_engine=engine,
        search_query=search_query or "",
        tag=tag,
        title=None,
        url=url,
        snippet=None,
        emails=scan["emails"],
        phones=scan["phones"],
        contact_urls=scan["contact_urls"],
        automation_intent_score=scan["automation_intent_score"],
        has_website_signal=not looks_like_directory_or_social_only(url),
        notes=None,
    )
    return lead.model_dump()


async def run_search_and_collect(
    *,
    engine: str,
    query: str,
    location_hint: Optional[str],
    max_results: int,
    tag: Optional[str],
    only_no_website: bool = False,
) -> Dict[str, Any]:
    q = query.strip()
    if location_hint:
        q = f"{q} {location_hint}".strip()

    async with browser_page() as page:
        results = await search_engine(page, engine, q, max_results)

    saved: List[Dict[str, Any]] = []
    scanned = 0
    async with browser_page() as page:
        for r in results:
            scanned += 1
            try:
                scan = await scan_page_for_lead(page, r.url)
                has_website = not looks_like_directory_or_social_only(r.url)
                if only_no_website and has_website:
                    continue
                lead = await upsert_lead(
                    source_engine=engine,
                    search_query=q,
                    tag=tag,
                    title=r.title,
                    url=r.url,
                    snippet=r.snippet,
                    emails=scan["emails"],
                    phones=scan["phones"],
                    contact_urls=scan["contact_urls"],
                    automation_intent_score=scan["automation_intent_score"],
                    has_website_signal=has_website,
                    notes=None,
                )
                saved.append(lead.model_dump())
            except Exception:
                continue

    return {
        "engine": engine,
        "query": q,
        "requested": max_results,
        "found": len(results),
        "scanned": scanned,
        "saved": len(saved),
        "leads": saved,
    }


async def run_maps_search(
    *,
    query: str,
    max_results: int,
    tag: Optional[str],
    only_no_website: bool = False,
) -> Dict[str, Any]:
    async with browser_page() as page:
        listings = await scrape_google_maps(page, query, max_results)

    saved: List[Dict[str, Any]] = []
    skipped_has_website = 0

    # For listings with a website, optionally audit it.
    async with browser_page() as page:
        for m in listings:
            if only_no_website and m.has_website:
                skipped_has_website += 1
                continue

            phones = [m.phone] if m.phone else []
            use_url = m.place_url or f"https://maps.google.com/?q={m.name}"

            site_audit = None
            social_profiles = None
            whatsapp_numbers = None

            # If the business has a website, audit it for quality + deep-crawl emails.
            if m.website:
                try:
                    site_audit = await audit_website(page, m.website, deep_crawl=True)
                    social_profiles = site_audit.social_profiles
                    whatsapp_numbers = site_audit.whatsapp_numbers
                    if site_audit.emails:
                        m.emails = uniq_keep_order([*m.emails, *site_audit.emails])
                    if site_audit.phones:
                        phones = uniq_keep_order([*phones, *site_audit.phones])
                except Exception as exc:
                    print(f"[MAPS] Audit failed for {m.website}: {exc}")

            try:
                lead = await upsert_lead(
                    source_engine="google_maps",
                    search_query=query,
                    tag=tag,
                    title=m.name,
                    url=use_url,
                    snippet=m.address,
                    emails=m.emails,
                    phones=phones,
                    contact_urls=[m.website] if m.website else [],
                    automation_intent_score=0,
                    has_website_signal=m.has_website,
                    notes=None,
                    maps_name=m.name,
                    maps_address=m.address,
                    maps_rating=m.rating,
                    maps_review_count=m.review_count,
                    maps_category=m.category,
                    maps_website=m.website if m.website else None,
                    maps_place_url=m.place_url,
                    site_audit=site_audit,
                    social_profiles=social_profiles,
                    whatsapp_numbers=whatsapp_numbers,
                )
                saved.append(lead.model_dump())
            except Exception as exc:
                log.warning("Failed to save Maps lead %s: %s", m.name, exc)
                continue

    return {
        "source": "google_maps",
        "query": query,
        "requested": max_results,
        "found": len(listings),
        "saved": len(saved),
        "skipped_has_website": skipped_has_website,
        "leads": saved,
    }
