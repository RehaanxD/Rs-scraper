from __future__ import annotations

import base64
import logging
import random
from typing import List
from urllib.parse import parse_qs, quote_plus, unquote, urlparse

from bs4 import BeautifulSoup
from playwright.async_api import Page

from backend.app.core.settings import settings
from backend.app.scrape.human import (
    check_and_handle_captcha,
    dismiss_google_consent,
    human_delay,
    human_scroll,
    human_type,
    random_mouse_movement,
)
from backend.app.scrape.utils import SearchResult, normalize_url

log = logging.getLogger("scraper.engines")

MAX_RETRIES = 3


# ---------------------------------------------------------------------------
# Google
# ---------------------------------------------------------------------------

async def _collect_links_google(page: Page) -> List[SearchResult]:
    html = await page.content()
    soup = BeautifulSoup(html, "lxml")
    results: List[SearchResult] = []
    for block in soup.select("div.g, div.MjjYud"):
        a = block.select_one("a[href]")
        h3 = block.select_one("h3")
        if not a or not h3:
            continue
        url = normalize_url(a.get("href", ""))
        title = (h3.get_text(" ", strip=True) or "").strip()
        snippet_el = block.select_one("div.VwiC3b, span.aCOpRe, div.IsZvec")
        snippet = (snippet_el.get_text(" ", strip=True) if snippet_el else "").strip()
        if url.startswith("/") or not url.startswith("http"):
            continue
        results.append(SearchResult(title=title, url=url, snippet=snippet))
    seen = set()
    out: List[SearchResult] = []
    for r in results:
        if r.url in seen:
            continue
        seen.add(r.url)
        out.append(r)
    return out


async def _google_search(page: Page, query: str, max_results: int) -> List[SearchResult]:
    # Navigate to Google homepage first (more human-like than direct search URL).
    await page.goto("https://www.google.com/", wait_until="domcontentloaded")
    await human_delay(800, 2000)

    # Handle consent popup.
    await dismiss_google_consent(page)
    await human_delay(300, 800)

    # Random mouse movement before typing.
    await random_mouse_movement(page)

    # Type the query like a human.
    try:
        await human_type(page, "textarea[name='q'], input[name='q']", query)
    except Exception:
        # Fallback: direct URL navigation.
        log.warning("Could not type into Google search box, falling back to direct URL")
        await page.goto(
            f"https://www.google.com/search?q={quote_plus(query)}&num=10",
            wait_until="domcontentloaded",
        )
        await human_delay(1000, 2500)
        await dismiss_google_consent(page)
        await human_delay(500, 1000)

        if await check_and_handle_captcha(page):
            log.warning("Google CAPTCHA detected, results may be incomplete")
            return []

        return (await _collect_links_google(page))[:max_results]

    await human_delay(300, 700)
    await page.keyboard.press("Enter")
    await page.wait_for_load_state("domcontentloaded")
    await human_delay(1500, 3000)

    # Handle consent that may appear after search.
    await dismiss_google_consent(page)

    # Check for CAPTCHA.
    if await check_and_handle_captcha(page):
        log.warning("Google CAPTCHA detected, results may be incomplete")
        return []

    results: List[SearchResult] = []
    pages_scraped = 0

    while len(results) < max_results:
        pages_scraped += 1

        await random_mouse_movement(page)
        await human_scroll(page, times=random.randint(1, 2))
        await human_delay(500, 1200)

        batch = await _collect_links_google(page)
        merged = results + [r for r in batch if r.url not in {x.url for x in results}]
        results = merged

        if len(results) >= max_results:
            break

        # Click next page.
        next_btn = await page.query_selector("a#pnnext, a[aria-label='Next']")
        if not next_btn:
            break

        await human_delay(800, 2000)
        await next_btn.click()
        await page.wait_for_load_state("domcontentloaded")
        await human_delay(2000, 4000)

        # Check for CAPTCHA on new page.
        if await check_and_handle_captcha(page):
            log.warning("Google CAPTCHA on page %d, stopping", pages_scraped + 1)
            break

    return results[:max_results]


# ---------------------------------------------------------------------------
# Bing
# ---------------------------------------------------------------------------

async def _collect_links_bing(page: Page) -> List[SearchResult]:
    html = await page.content()
    soup = BeautifulSoup(html, "lxml")
    out: List[SearchResult] = []
    for li in soup.select("li.b_algo"):
        a = li.select_one("h2 a[href]")
        if not a:
            continue
        title = a.get_text(" ", strip=True)
        url = normalize_url(a.get("href", ""))

        try:
            pu = urlparse(url)
            if "bing.com" in (pu.netloc or "") and pu.path.startswith("/ck/a"):
                qs = parse_qs(pu.query or "")
                u = qs.get("u", [None])[0]
                if u:
                    if u.startswith("a1"):
                        u = u[2:]
                    pad = "=" * ((4 - (len(u) % 4)) % 4)
                    decoded = base64.urlsafe_b64decode((u + pad).encode("utf-8")).decode(
                        "utf-8", errors="ignore"
                    )
                    if decoded.startswith(("http://", "https://")):
                        url = decoded
        except Exception:
            pass

        snippet_el = li.select_one("div.b_caption p")
        snippet = (snippet_el.get_text(" ", strip=True) if snippet_el else "").strip()
        if url:
            out.append(SearchResult(title=title, url=url, snippet=snippet))
    return out


async def _bing_search(page: Page, query: str, max_results: int) -> List[SearchResult]:
    await page.goto("https://www.bing.com/", wait_until="domcontentloaded")
    await human_delay(800, 1800)
    await random_mouse_movement(page)

    try:
        await human_type(page, "input[name='q'], input#sb_form_q, textarea[name='q']", query)
    except Exception:
        log.warning("Could not type into Bing, falling back to direct URL")
        await page.goto(
            f"https://www.bing.com/search?q={quote_plus(query)}",
            wait_until="domcontentloaded",
        )
        await human_delay(1000, 2500)
        return (await _collect_links_bing(page))[:max_results]

    await human_delay(300, 700)
    await page.keyboard.press("Enter")
    await page.wait_for_load_state("domcontentloaded")
    await human_delay(1500, 3000)

    results: List[SearchResult] = []

    while len(results) < max_results:
        await random_mouse_movement(page)
        await human_scroll(page, times=random.randint(1, 2))
        await human_delay(500, 1000)

        batch = await _collect_links_bing(page)
        results = results + [r for r in batch if r.url not in {x.url for x in results}]
        if len(results) >= max_results:
            break

        next_btn = await page.query_selector("a.sb_pagN")
        if not next_btn:
            break

        await human_delay(800, 2000)
        await next_btn.click()
        await page.wait_for_load_state("domcontentloaded")
        await human_delay(1500, 3000)

    return results[:max_results]


# ---------------------------------------------------------------------------
# DuckDuckGo
# ---------------------------------------------------------------------------

async def _collect_links_ddg(page: Page) -> List[SearchResult]:
    out: List[SearchResult] = []

    loc = page.locator("a[data-testid='result-title-a'], a.result__a")
    count = await loc.count()
    for i in range(min(count, 50)):
        el = loc.nth(i)
        try:
            url = normalize_url((await el.get_attribute("href")) or "")
            title = normalize_url((await el.inner_text()) or "")
        except Exception:
            continue
        if not url:
            continue

        try:
            pu = urlparse(url)
            if "duckduckgo.com" in (pu.netloc or "") and pu.path.startswith("/l/"):
                qs = parse_qs(pu.query or "")
                uddg = qs.get("uddg", [None])[0]
                if uddg:
                    url = unquote(uddg)
        except Exception:
            pass

        if url.startswith(("http://", "https://")):
            out.append(SearchResult(title=title, url=url, snippet=""))

    seen = set()
    deduped: List[SearchResult] = []
    for r in out:
        if r.url in seen:
            continue
        seen.add(r.url)
        deduped.append(r)
    return deduped


async def _ddg_search(page: Page, query: str, max_results: int) -> List[SearchResult]:
    await page.goto("https://duckduckgo.com/", wait_until="domcontentloaded")
    await human_delay(800, 1800)
    await random_mouse_movement(page)

    try:
        await human_type(page, "input[name='q']", query)
    except Exception:
        log.warning("Could not type into DDG, falling back to direct URL")
        await page.goto(
            f"https://duckduckgo.com/?q={quote_plus(query)}",
            wait_until="domcontentloaded",
        )
        await human_delay(1000, 2500)

        try:
            await page.wait_for_load_state("networkidle")
        except Exception:
            pass
        try:
            await page.wait_for_selector(
                "a[data-testid='result-title-a'], a.result__a", timeout=12_000
            )
        except Exception:
            pass
        return (await _collect_links_ddg(page))[:max_results]

    await human_delay(300, 700)
    await page.keyboard.press("Enter")
    await page.wait_for_load_state("domcontentloaded")
    await human_delay(1500, 3000)

    try:
        await page.wait_for_selector(
            "a[data-testid='result-title-a'], a.result__a", timeout=12_000
        )
    except Exception:
        pass

    results: List[SearchResult] = []
    for _ in range(10):
        batch = await _collect_links_ddg(page)
        results = results + [r for r in batch if r.url not in {x.url for x in results}]
        if len(results) >= max_results:
            break
        await human_scroll(page, times=1)
        await human_delay(500, 1200)
    return results[:max_results]


# ---------------------------------------------------------------------------
# Public entry point with retry
# ---------------------------------------------------------------------------

async def search_engine(
    page: Page, engine: str, query: str, max_results: int
) -> List[SearchResult]:
    engine = engine.lower().strip()
    q = query.strip()

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            if engine == "google":
                results = await _google_search(page, q, max_results)
            elif engine == "bing":
                results = await _bing_search(page, q, max_results)
            elif engine == "ddg":
                results = await _ddg_search(page, q, max_results)
            else:
                raise ValueError(f"Unknown engine: {engine}")

            if results:
                log.info(
                    "Engine=%s attempt=%d found=%d results", engine, attempt, len(results)
                )
                return results

            log.warning("Engine=%s attempt=%d returned 0 results, retrying...", engine, attempt)
            await human_delay(3000, 6000)

        except Exception as exc:
            log.warning("Engine=%s attempt=%d error: %s", engine, attempt, exc)
            backoff_ms = min(2000 * (2 ** attempt), 20_000) + random.randint(0, 2000)
            await human_delay(backoff_ms, backoff_ms + 2000)

    log.error("Engine=%s all %d attempts failed, returning empty", engine, MAX_RETRIES)
    return []
