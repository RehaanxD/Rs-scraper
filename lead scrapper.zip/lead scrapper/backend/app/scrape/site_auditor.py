"""Website quality auditor — checks SSL, mobile-friendliness, page speed,
social profiles, and deep-crawls for emails."""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from urllib.parse import urljoin, urlparse

from playwright.async_api import Page

from backend.app.scrape.human import human_delay
from backend.app.scrape.utils import extract_emails, extract_phones, uniq_keep_order


SOCIAL_PATTERNS: Dict[str, re.Pattern] = {
    "facebook": re.compile(r"https?://(?:www\.)?facebook\.com/[a-zA-Z0-9._%-]+", re.I),
    "instagram": re.compile(r"https?://(?:www\.)?instagram\.com/[a-zA-Z0-9._%-]+", re.I),
    "twitter": re.compile(r"https?://(?:www\.)?(?:twitter|x)\.com/[a-zA-Z0-9._%-]+", re.I),
    "linkedin": re.compile(r"https?://(?:www\.)?linkedin\.com/(?:company|in)/[a-zA-Z0-9._%-]+", re.I),
    "tiktok": re.compile(r"https?://(?:www\.)?tiktok\.com/@[a-zA-Z0-9._%-]+", re.I),
    "youtube": re.compile(r"https?://(?:www\.)?youtube\.com/(?:@|channel/|c/)[a-zA-Z0-9._%-]+", re.I),
}

WHATSAPP_RE = re.compile(
    r"(?:https?://)?(?:wa\.me/|api\.whatsapp\.com/send\?phone=|whatsapp\.com/send\?phone=)(\d+)",
    re.I,
)
WHATSAPP_LINK_RE = re.compile(r"wa\.me/\d+|whatsapp\.com/send", re.I)


@dataclass
class SiteAudit:
    url: str = ""
    has_ssl: bool = False
    is_mobile_friendly: bool = True
    load_time_ms: int = 0
    page_size_kb: int = 0
    has_viewport_meta: bool = True
    title: str = ""
    uses_modern_tech: bool = False

    # Social profiles found.
    social_profiles: Dict[str, str] = field(default_factory=dict)
    whatsapp_numbers: List[str] = field(default_factory=list)

    # Deep-crawled contact info.
    emails: List[str] = field(default_factory=list)
    phones: List[str] = field(default_factory=list)

    # Quality score 0-100 (higher = better site, lower = better lead).
    quality_score: int = 50

    pages_crawled: int = 0


AUDIT_JS = """
() => {
    const info = {};

    // Viewport meta tag check.
    const vpMeta = document.querySelector('meta[name="viewport"]');
    info.has_viewport_meta = !!vpMeta;

    // Page title.
    info.title = document.title || '';

    // Check for modern tech signals.
    const html = document.documentElement.outerHTML || '';
    info.uses_react = html.includes('__NEXT_DATA__') || html.includes('_reactRoot')
        || html.includes('react-root') || html.includes('__nuxt');
    info.uses_wordpress = html.includes('wp-content') || html.includes('wordpress');
    info.uses_wix = html.includes('wix.com') || html.includes('_wixCssRecovery');
    info.uses_squarespace = html.includes('squarespace');
    info.uses_shopify = html.includes('shopify') || html.includes('cdn.shopify');

    // Check for HTTPS mixed content warnings.
    info.has_mixed_content = html.includes('http://') && window.location.protocol === 'https:';

    // Collect all links (for social + crawling).
    const links = [];
    document.querySelectorAll('a[href]').forEach(a => {
        links.push(a.href);
    });
    info.links = links;

    // Page text for email/phone extraction.
    info.body_text = (document.body ? document.body.innerText : '').substring(0, 50000);

    return info;
}
"""


def _extract_social_profiles(links: List[str], text: str) -> Dict[str, str]:
    profiles: Dict[str, str] = {}
    combined = " ".join(links) + " " + text
    for platform, pattern in SOCIAL_PATTERNS.items():
        match = pattern.search(combined)
        if match:
            profiles[platform] = match.group(0)
    return profiles


def _extract_whatsapp(links: List[str], text: str) -> List[str]:
    combined = " ".join(links) + " " + text
    numbers = WHATSAPP_RE.findall(combined)
    return uniq_keep_order(numbers)


def _compute_quality_score(audit: SiteAudit) -> int:
    score = 50

    if audit.has_ssl:
        score += 15
    else:
        score -= 20

    if audit.has_viewport_meta:
        score += 10
    else:
        score -= 15

    if audit.load_time_ms < 3000:
        score += 10
    elif audit.load_time_ms > 8000:
        score -= 10

    if audit.uses_modern_tech:
        score += 10

    if len(audit.social_profiles) >= 2:
        score += 5

    return max(0, min(100, score))


async def audit_website(page: Page, url: str, deep_crawl: bool = True) -> SiteAudit:
    audit = SiteAudit(url=url)

    parsed = urlparse(url)
    audit.has_ssl = parsed.scheme == "https"

    start = time.monotonic()
    try:
        response = await page.goto(url, wait_until="domcontentloaded")
        audit.load_time_ms = int((time.monotonic() - start) * 1000)

        if response:
            headers = response.headers
            content_length = headers.get("content-length", "0")
            audit.page_size_kb = int(content_length) // 1024 if content_length.isdigit() else 0
    except Exception:
        audit.load_time_ms = int((time.monotonic() - start) * 1000)
        return audit

    await human_delay(500, 1000)

    try:
        info = await page.evaluate(AUDIT_JS)
    except Exception:
        return audit

    audit.has_viewport_meta = info.get("has_viewport_meta", True)
    audit.title = info.get("title", "")
    audit.uses_modern_tech = any([
        info.get("uses_react"),
        info.get("uses_wordpress"),
        info.get("uses_shopify"),
    ])

    links = info.get("links", [])
    body_text = info.get("body_text", "")

    audit.social_profiles = _extract_social_profiles(links, body_text)
    audit.whatsapp_numbers = _extract_whatsapp(links, body_text)
    audit.emails = extract_emails(body_text)
    audit.phones = extract_phones(body_text)
    audit.pages_crawled = 1

    # Deep crawl: visit contact, about, and other key pages.
    if deep_crawl:
        crawl_paths = ["/contact", "/contact-us", "/about", "/about-us"]
        internal_links = [
            l for l in links
            if parsed.netloc in l and any(h in l.lower() for h in crawl_paths)
        ]

        # Also add standard paths if not found in links.
        base = f"{parsed.scheme}://{parsed.netloc}"
        for path in crawl_paths:
            candidate = urljoin(base, path)
            if candidate not in internal_links:
                internal_links.append(candidate)

        for link in internal_links[:4]:
            try:
                await page.goto(link, wait_until="domcontentloaded")
                await human_delay(500, 1000)
                sub_info = await page.evaluate(AUDIT_JS)
                sub_text = sub_info.get("body_text", "")
                sub_links = sub_info.get("links", [])

                audit.emails = uniq_keep_order([*audit.emails, *extract_emails(sub_text)])
                audit.phones = uniq_keep_order([*audit.phones, *extract_phones(sub_text)])

                sub_social = _extract_social_profiles(sub_links, sub_text)
                for k, v in sub_social.items():
                    if k not in audit.social_profiles:
                        audit.social_profiles[k] = v

                sub_wa = _extract_whatsapp(sub_links, sub_text)
                audit.whatsapp_numbers = uniq_keep_order([*audit.whatsapp_numbers, *sub_wa])

                audit.pages_crawled += 1
            except Exception:
                continue

    audit.quality_score = _compute_quality_score(audit)
    return audit
