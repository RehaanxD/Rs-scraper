from __future__ import annotations

import logging
import random
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

from playwright.async_api import Browser, BrowserContext, Page, async_playwright

from backend.app.core.settings import get_proxy_list, settings
from backend.app.scrape.stealth import (
    build_stealth_js,
    load_cookies,
    pick_random_profile,
    save_cookies,
)

log = logging.getLogger("scraper.browsers")

CHROMIUM_ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-features=IsolateOrigins,site-per-process",
    "--disable-infobars",
    "--disable-dev-shm-usage",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--disable-renderer-backgrounding",
    "--disable-component-update",
    "--disable-hang-monitor",
    "--disable-prompt-on-repost",
    "--disable-sync",
    "--metrics-recording-only",
    "--no-service-autorun",
    "--password-store=basic",
    "--lang=en-US",
]

PROFILE_DIR = Path("data/browser_profile")


def _pick_proxy() -> dict | None:
    proxies = get_proxy_list()
    if not proxies:
        return None
    chosen = random.choice(proxies)
    proxy: dict = {"server": chosen}
    if "@" in chosen:
        parts = chosen.split("://", 1)
        scheme = parts[0] if len(parts) > 1 else "http"
        rest = parts[-1]
        creds, host = rest.rsplit("@", 1)
        user, pwd = creds.split(":", 1) if ":" in creds else (creds, "")
        proxy = {"server": f"{scheme}://{host}", "username": user, "password": pwd}
    return proxy


@asynccontextmanager
async def browser_page() -> AsyncIterator[Page]:
    ua, vp = pick_random_profile()
    stealth_js = build_stealth_js()
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)

    proxy = _pick_proxy()

    async with async_playwright() as p:
        browser: Browser | None = None
        launch_kwargs: dict = {
            "headless": settings.headless,
            "slow_mo": settings.slow_mo_ms,
            "args": CHROMIUM_ARGS,
        }
        if proxy:
            launch_kwargs["proxy"] = proxy
            log.info("Using proxy: %s", proxy["server"])

        for channel in ("chrome", "msedge", None):
            try:
                browser = await p.chromium.launch(channel=channel, **launch_kwargs)
                if channel:
                    log.info("Launched real browser via channel=%s", channel)
                break
            except Exception:
                continue

        if browser is None:
            browser = await p.chromium.launch(**launch_kwargs)

        context: BrowserContext = await browser.new_context(
            locale="en-US",
            timezone_id="America/New_York",
            viewport=vp,
            screen=vp,
            user_agent=ua,
            color_scheme="light",
            java_script_enabled=True,
            bypass_csp=True,
            extra_http_headers={
                "Accept-Language": "en-US,en;q=0.9",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Encoding": "gzip, deflate, br",
                "Sec-Ch-Ua": '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
                "Sec-Ch-Ua-Mobile": "?0",
                "Sec-Ch-Ua-Platform": '"Windows"',
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
            },
        )

        saved_cookies = load_cookies()
        if saved_cookies:
            try:
                await context.add_cookies(saved_cookies)
            except Exception:
                pass

        await context.add_init_script(stealth_js)

        page = await context.new_page()
        page.set_default_navigation_timeout(settings.nav_timeout_ms)
        page.set_default_timeout(settings.nav_timeout_ms)

        try:
            yield page
        finally:
            try:
                cookies = await context.cookies()
                save_cookies(cookies)
            except Exception:
                pass
            await context.close()
            await browser.close()
