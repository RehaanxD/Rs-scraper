from __future__ import annotations

import random
import re
import time
from dataclasses import dataclass
from typing import Iterable, List, Optional, Set, Tuple

import tldextract


EMAIL_RE = re.compile(r"(?i)([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,})")
PHONE_RE = re.compile(
    r"(?x)"
    r"(\+?\d{1,3}[\s\-().]*)?"
    r"(\d{2,4}[\s\-().]*)"
    r"(\d{3,4}[\s\-().]*)"
    r"(\d{3,4})"
)


AUTOMATION_KEYWORDS = [
    "manual",
    "spreadsheet",
    "excel",
    "paperwork",
    "bookings",
    "booking",
    "appointments",
    "invoice",
    "invoicing",
    "dispatch",
    "quotes",
    "quotation",
    "inventory",
    "order management",
    "crm",
    "follow up",
    "data entry",
    "admin work",
    "reporting",
    "whatsapp orders",
    "phone orders",
]


def domain_from_url(url: str) -> Optional[str]:
    try:
        ext = tldextract.extract(url)
        if not ext.registered_domain:
            return None
        return ext.registered_domain.lower()
    except Exception:
        return None


def uniq_keep_order(items: Iterable[str]) -> List[str]:
    out: List[str] = []
    seen: Set[str] = set()
    for x in items:
        x2 = x.strip()
        if not x2:
            continue
        if x2 in seen:
            continue
        seen.add(x2)
        out.append(x2)
    return out


def _is_valid_email(e: str) -> bool:
    if len(e) < 6 or "@" not in e:
        return False
    local, _, domain = e.partition("@")
    if not local or not domain or "." not in domain:
        return False
    if domain.endswith((".png", ".jpg", ".gif", ".svg", ".css", ".js")):
        return False
    return True


def extract_emails(text: str) -> List[str]:
    raw = uniq_keep_order(m[0] for m in EMAIL_RE.findall(text or ""))
    return [e for e in raw if _is_valid_email(e)]


def extract_phones(text: str) -> List[str]:
    phones: List[str] = []
    for m in PHONE_RE.findall(text or ""):
        raw = "".join(m)
        cleaned = re.sub(r"[^\d+]", "", raw)
        if len(re.sub(r"[^\d]", "", cleaned)) >= 9:
            phones.append(cleaned)
    return uniq_keep_order(phones)


def score_automation_intent(text: str) -> int:
    t = (text or "").lower()
    score = 0
    for kw in AUTOMATION_KEYWORDS:
        if kw in t:
            score += 1
    return score


def sleep_jitter(min_ms: int, max_ms: int) -> None:
    ms = random.randint(min_ms, max_ms)
    time.sleep(ms / 1000.0)


def looks_like_directory_or_social_only(url: str) -> bool:
    u = (url or "").lower()
    bad = [
        "facebook.com",
        "instagram.com",
        "twitter.com",
        "x.com",
        "tiktok.com",
        "vk.com",
        "yelp.",
        "yellowpages",
        "opencorporates",
        "companieshouse",
        "linkedin.com/company",
        "indeed.com",
        "glassdoor",
        "trustpilot",
        "tripadvisor",
        "mapquest",
        "google.com/maps",
    ]
    return any(b in u for b in bad)


CONTACT_HINTS = [
    "/contact",
    "/contact-us",
    "/get-a-quote",
    "/quote",
    "/enquire",
    "/enquiry",
    "/book",
    "/booking",
    "/appointment",
]


def normalize_url(url: str) -> str:
    return (url or "").strip()


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str = ""

