from __future__ import annotations

import json
import os
import random
from pathlib import Path
from typing import List, Optional, Tuple

from backend.app.core.settings import settings

COOKIE_DIR = Path("data")
COOKIE_FILE = COOKIE_DIR / "cookies.json"

USER_AGENTS: List[str] = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
]

VIEWPORTS: List[dict] = [
    {"width": 1920, "height": 1080},
    {"width": 1536, "height": 864},
    {"width": 1440, "height": 900},
    {"width": 1366, "height": 768},
    {"width": 1280, "height": 800},
    {"width": 1280, "height": 720},
]

WEBGL_VENDORS = ["Intel Inc.", "Google Inc. (Intel)", "Google Inc. (NVIDIA)"]
WEBGL_RENDERERS = [
    "Intel Iris OpenGL Engine",
    "ANGLE (Intel, Intel(R) UHD Graphics 630, OpenGL 4.5)",
    "ANGLE (NVIDIA, NVIDIA GeForce GTX 1650, OpenGL 4.5)",
]

# JS to inject BEFORE page loads to hide automation signals.
STEALTH_JS = """
() => {
    // 1) Hide navigator.webdriver
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });

    // 2) Fake plugins (Chrome normally has 5)
    Object.defineProperty(navigator, 'plugins', {
        get: () => {
            const arr = [
                { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer', description: 'Portable Document Format' },
                { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai', description: '' },
                { name: 'Native Client', filename: 'internal-nacl-plugin', description: '' },
            ];
            arr.item = (i) => arr[i];
            arr.namedItem = (n) => arr.find(p => p.name === n) || null;
            arr.refresh = () => {};
            return arr;
        }
    });

    // 3) Fake languages
    Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
    Object.defineProperty(navigator, 'language', { get: () => 'en-US' });

    // 4) Fake platform
    Object.defineProperty(navigator, 'platform', { get: () => 'Win32' });

    // 5) Fake hardwareConcurrency / deviceMemory
    Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
    Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });

    // 6) Spoof WebGL vendor/renderer
    const getParameter = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(param) {
        if (param === 37445) return '""" + "WEBGL_VENDOR" + """';
        if (param === 37446) return '""" + "WEBGL_RENDERER" + """';
        return getParameter.call(this, param);
    };

    // 7) Remove "cdc_" markers Chromium leaves
    for (const key of Object.keys(window)) {
        if (/^cdc_|^\\$cdc_/.test(key)) {
            delete window[key];
        }
    }

    // 8) Fake permissions API to not reveal "denied" for notifications
    const originalQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (params) => {
        if (params.name === 'notifications') {
            return Promise.resolve({ state: Notification.permission });
        }
        return originalQuery(params);
    };

    // 9) Pass Chrome runtime check
    window.chrome = { runtime: {}, loadTimes: function(){}, csi: function(){} };

    // 10) Fake connection type
    Object.defineProperty(navigator, 'connection', {
        get: () => ({ effectiveType: '4g', rtt: 50, downlink: 10, saveData: false })
    });
}
"""


def pick_random_profile() -> Tuple[str, dict]:
    ua = random.choice(USER_AGENTS)
    vp = random.choice(VIEWPORTS)
    return ua, vp


def build_stealth_js() -> str:
    vendor = random.choice(WEBGL_VENDORS)
    renderer = random.choice(WEBGL_RENDERERS)
    return STEALTH_JS.replace("WEBGL_VENDOR", vendor).replace("WEBGL_RENDERER", renderer)


def load_cookies() -> Optional[list]:
    try:
        if COOKIE_FILE.exists():
            data = json.loads(COOKIE_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
    except Exception:
        pass
    return None


def save_cookies(cookies: list) -> None:
    try:
        COOKIE_DIR.mkdir(parents=True, exist_ok=True)
        COOKIE_FILE.write_text(json.dumps(cookies, indent=2), encoding="utf-8")
    except Exception:
        pass


GOOGLE_CONSENT_SELECTORS = [
    "button#L2AGLb",
    "button[aria-label='Accept all']",
    "button:has-text('Accept all')",
    "button:has-text('I agree')",
    "button:has-text('Acepto')",
    "button:has-text('Aceptar todo')",
    "button:has-text('Alle akzeptieren')",
    "button:has-text('Tout accepter')",
    "form[action*='consent'] button",
    "div[role='dialog'] button:first-of-type",
]

CAPTCHA_INDICATORS = [
    "unusual traffic",
    "not a robot",
    "recaptcha",
    "captcha",
    "automated queries",
    "sorry/index",
    "ipv4.google.com/sorry",
]


def is_captcha_page(url: str, page_text: str) -> bool:
    ul = (url or "").lower()
    tl = (page_text or "").lower()[:3000]
    return any(ind in ul or ind in tl for ind in CAPTCHA_INDICATORS)
