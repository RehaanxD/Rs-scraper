from __future__ import annotations

from typing import List, Tuple

from bs4 import BeautifulSoup
from playwright.async_api import Page

from backend.app.core.settings import settings
from backend.app.scrape.utils import (
    CONTACT_HINTS,
    extract_emails,
    extract_phones,
    normalize_url,
    score_automation_intent,
    sleep_jitter,
    uniq_keep_order,
)


async def fetch_text_and_links(page: Page, url: str) -> Tuple[str, List[str]]:
    await page.goto(url, wait_until="domcontentloaded")
    sleep_jitter(settings.min_delay_ms, settings.max_delay_ms)
    html = await page.content()
    soup = BeautifulSoup(html, "lxml")
    text = soup.get_text(" ", strip=True)
    links: List[str] = []
    for a in soup.select("a[href]"):
        href = normalize_url(a.get("href", ""))
        if not href:
            continue
        # Ignore non-http links
        if href.startswith("mailto:") or href.startswith("tel:"):
            continue
        if href.startswith("http://") or href.startswith("https://"):
            links.append(href)
        elif href.startswith("/"):
            # build absolute from current origin
            try:
                origin = (await page.evaluate("() => location.origin")) or ""
            except Exception:
                origin = ""
            if origin:
                links.append(origin.rstrip("/") + href)
    return text, uniq_keep_order(links)


def pick_contact_links(links: List[str]) -> List[str]:
    picked: List[str] = []
    for u in links:
        ul = u.lower()
        if any(h in ul for h in CONTACT_HINTS) or ("contact" in ul) or ("quote" in ul):
            picked.append(u)
    return uniq_keep_order(picked)[:8]


async def scan_page_for_lead(page: Page, url: str) -> dict:
    text, links = await fetch_text_and_links(page, url)
    emails = extract_emails(text)
    phones = extract_phones(text)
    score = score_automation_intent(text)

    contact_links = pick_contact_links(links)
    # If we didn't find any email/phone, try a couple contact pages.
    if (not emails and not phones) and contact_links:
        for cu in contact_links[:2]:
            try:
                sleep_jitter(settings.min_delay_ms, settings.max_delay_ms)
                t2, _ = await fetch_text_and_links(page, cu)
                emails = uniq_keep_order([*emails, *extract_emails(t2)])
                phones = uniq_keep_order([*phones, *extract_phones(t2)])
                score = max(score, score_automation_intent(t2))
            except Exception:
                continue

    return {
        "emails": emails,
        "phones": phones,
        "contact_urls": contact_links,
        "automation_intent_score": int(score),
        "page_text_sample": (text or "")[:2000],
    }

