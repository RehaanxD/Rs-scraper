from __future__ import annotations

import csv
import io
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import PlainTextResponse, Response
from sqlmodel import func, select

from backend.app.api.schemas import MapsSearchRequest, ScanUrlRequest, ScheduleRequest, SearchRequest
from backend.app.db.models import Lead, ScheduledSearch
from backend.app.db.session import session_factory
from backend.app.scrape.pipeline import run_maps_search, run_search_and_collect, scan_single_url


router = APIRouter()


# ── Search endpoints ─────────────────────────────────────────────
@router.post("/search")
async def search(req: SearchRequest) -> Dict[str, Any]:
    return await run_search_and_collect(
        engine=req.engine,
        query=req.query,
        location_hint=req.location_hint,
        max_results=req.max_results,
        tag=req.tag,
        only_no_website=req.only_no_website,
    )


@router.post("/maps-search")
async def maps_search(req: MapsSearchRequest) -> Dict[str, Any]:
    return await run_maps_search(
        query=req.query,
        max_results=req.max_results,
        tag=req.tag,
        only_no_website=req.only_no_website,
    )


@router.post("/scan-url")
async def scan_url(req: ScanUrlRequest) -> Dict[str, Any]:
    try:
        lead = await scan_single_url(
            url=req.url, engine=req.engine, search_query=req.search_query, tag=req.tag
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"saved": True, "lead": lead}


# ── Lead CRUD ────────────────────────────────────────────────────
@router.get("/leads")
async def leads(
    limit: int = 200,
    offset: int = 0,
    tag: Optional[str] = None,
    no_website_only: bool = False,
    source: Optional[str] = None,
    min_score: Optional[int] = None,
    grade: Optional[str] = None,
) -> List[Lead]:
    async with session_factory() as session:
        stmt = select(Lead).order_by(Lead.lead_score.desc(), Lead.created_at.desc()).offset(offset).limit(limit)
        if tag:
            stmt = stmt.where(Lead.tag == tag)
        if no_website_only:
            stmt = stmt.where(Lead.has_website_signal.is_(False))
        if source:
            stmt = stmt.where(Lead.source_engine == source)
        if min_score is not None:
            stmt = stmt.where(Lead.lead_score >= min_score)
        if grade:
            stmt = stmt.where(Lead.lead_grade == grade.upper())
        return list((await session.exec(stmt)).all())


@router.get("/leads/{lead_id}")
async def lead(lead_id: int) -> Lead:
    async with session_factory() as session:
        row = await session.get(Lead, lead_id)
        if not row:
            raise HTTPException(status_code=404, detail="Not found")
        return row


@router.delete("/leads/{lead_id}")
async def delete_lead(lead_id: int) -> Dict[str, Any]:
    async with session_factory() as session:
        row = await session.get(Lead, lead_id)
        if not row:
            raise HTTPException(status_code=404, detail="Not found")
        await session.delete(row)
        await session.commit()
    return {"deleted": True, "id": lead_id}


# ── Export CSV ───────────────────────────────────────────────────
@router.get("/export.csv", response_class=PlainTextResponse)
async def export_csv(
    tag: Optional[str] = None,
    no_website_only: bool = False,
    source: Optional[str] = None,
) -> str:
    async with session_factory() as session:
        stmt = select(Lead).order_by(Lead.lead_score.desc())
        if tag:
            stmt = stmt.where(Lead.tag == tag)
        if no_website_only:
            stmt = stmt.where(Lead.has_website_signal.is_(False))
        if source:
            stmt = stmt.where(Lead.source_engine == source)
        rows = list((await session.exec(stmt)).all())

    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(_csv_header())
    for r in rows:
        w.writerow(_csv_row(r))
    return buf.getvalue()


# ── Export Excel ─────────────────────────────────────────────────
@router.get("/export.xlsx")
async def export_xlsx(
    tag: Optional[str] = None,
    no_website_only: bool = False,
    source: Optional[str] = None,
) -> Response:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    async with session_factory() as session:
        stmt = select(Lead).order_by(Lead.lead_score.desc())
        if tag:
            stmt = stmt.where(Lead.tag == tag)
        if no_website_only:
            stmt = stmt.where(Lead.has_website_signal.is_(False))
        if source:
            stmt = stmt.where(Lead.source_engine == source)
        rows = list((await session.exec(stmt)).all())

    wb = Workbook()
    ws = wb.active
    ws.title = "Leads"

    header = _xlsx_header()
    header_fill = PatternFill(start_color="111827", end_color="111827", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True, size=11)

    for col, h in enumerate(header, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")

    # Grade colors
    grade_fills = {
        "A": PatternFill(start_color="D1FAE5", end_color="D1FAE5", fill_type="solid"),
        "B": PatternFill(start_color="DBEAFE", end_color="DBEAFE", fill_type="solid"),
        "C": PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid"),
        "D": PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid"),
    }
    no_web_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")

    for row_idx, r in enumerate(rows, 2):
        data = _xlsx_row(r)
        for col, val in enumerate(data, 1):
            cell = ws.cell(row=row_idx, column=col, value=val)

        # Color the grade cell.
        grade_col = header.index("Grade") + 1
        grade_val = r.lead_grade or "D"
        ws.cell(row=row_idx, column=grade_col).fill = grade_fills.get(grade_val, grade_fills["D"])

        # Highlight "No" in Has Website column.
        has_web_col = header.index("Has Website") + 1
        if r.has_website_signal is False:
            ws.cell(row=row_idx, column=has_web_col).fill = no_web_fill
            ws.cell(row=row_idx, column=has_web_col).font = Font(bold=True, color="991B1B")

    # Auto-width columns.
    for col in range(1, len(header) + 1):
        max_len = len(str(header[col - 1]))
        for row_idx in range(2, min(len(rows) + 2, 50)):
            cell_val = ws.cell(row=row_idx, column=col).value
            if cell_val:
                max_len = max(max_len, min(len(str(cell_val)), 50))
        ws.column_dimensions[get_column_letter(col)].width = max_len + 3

    ws.auto_filter.ref = ws.dimensions

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    return Response(
        content=buf.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=r_scrapper_leads.xlsx"},
    )


def _csv_header() -> List[str]:
    return [
        "id", "created_at", "source", "query", "tag", "lead_score", "grade",
        "business_name", "title", "url", "domain", "emails", "phones",
        "whatsapp", "address", "category", "rating", "reviews", "website",
        "has_own_website", "ssl", "mobile_friendly", "load_time_ms",
        "site_quality", "social_profiles", "automation_score", "snippet",
    ]


def _xlsx_header() -> List[str]:
    return [
        "Score", "Grade", "Business Name", "Phone", "Email", "WhatsApp",
        "Has Website", "Website", "Address", "Category", "Rating", "Reviews",
        "Social Profiles", "SSL", "Mobile", "Load Time",
        "Site Quality", "Source", "Tag",
    ]


def _csv_row(r: Lead) -> List:
    return [
        r.id,
        r.created_at.isoformat() if isinstance(r.created_at, datetime) else r.created_at,
        r.source_engine,
        r.search_query,
        r.tag or "",
        r.lead_score,
        r.lead_grade or "",
        r.maps_name or "",
        r.title or "",
        r.url,
        r.domain or "",
        r.emails_csv or "",
        r.phones_csv or "",
        r.whatsapp_csv or "",
        r.maps_address or "",
        r.maps_category or "",
        r.maps_rating or "",
        r.maps_review_count or "",
        r.maps_website or "",
        "" if r.has_website_signal is None else str(bool(r.has_website_signal)),
        "" if r.site_has_ssl is None else str(bool(r.site_has_ssl)),
        "" if r.site_is_mobile_friendly is None else str(bool(r.site_is_mobile_friendly)),
        r.site_load_time_ms or "",
        r.site_quality_score or "",
        r.social_profiles_csv or "",
        r.automation_intent_score,
        (r.snippet or "")[:5000],
    ]


def _xlsx_row(r: Lead) -> List:
    return [
        r.lead_score,
        r.lead_grade or "D",
        r.maps_name or r.title or "",
        r.phones_csv or "",
        r.emails_csv or "",
        r.whatsapp_csv or "",
        "No" if r.has_website_signal is False else ("Yes" if r.has_website_signal else "?"),
        r.maps_website or "",
        r.maps_address or "",
        r.maps_category or "",
        r.maps_rating or "",
        r.maps_review_count or "",
        r.social_profiles_csv or "",
        "Yes" if r.site_has_ssl else ("No" if r.site_has_ssl is False else ""),
        "Yes" if r.site_is_mobile_friendly else ("No" if r.site_is_mobile_friendly is False else ""),
        r.site_load_time_ms or "",
        r.site_quality_score or "",
        r.source_engine,
        r.tag or "",
    ]


# ── Dashboard stats ──────────────────────────────────────────────
@router.get("/stats")
async def stats() -> Dict[str, Any]:
    async with session_factory() as session:
        total = (await session.exec(select(func.count(Lead.id)))).one()

        no_website = (
            await session.exec(
                select(func.count(Lead.id)).where(Lead.has_website_signal.is_(False))
            )
        ).one()

        has_website = (
            await session.exec(
                select(func.count(Lead.id)).where(Lead.has_website_signal.is_(True))
            )
        ).one()

        with_phone = (
            await session.exec(
                select(func.count(Lead.id)).where(Lead.phones_csv.isnot(None))
            )
        ).one()

        with_email = (
            await session.exec(
                select(func.count(Lead.id)).where(Lead.emails_csv.isnot(None))
            )
        ).one()

        # Grade distribution
        grade_a = (await session.exec(select(func.count(Lead.id)).where(Lead.lead_grade == "A"))).one()
        grade_b = (await session.exec(select(func.count(Lead.id)).where(Lead.lead_grade == "B"))).one()
        grade_c = (await session.exec(select(func.count(Lead.id)).where(Lead.lead_grade == "C"))).one()
        grade_d = (await session.exec(select(func.count(Lead.id)).where(Lead.lead_grade == "D"))).one()

        # Source distribution
        sources_raw = (
            await session.exec(
                select(Lead.source_engine, func.count(Lead.id))
                .group_by(Lead.source_engine)
            )
        ).all()
        sources = {s: c for s, c in sources_raw}

        # Top tags
        tags_raw = (
            await session.exec(
                select(Lead.tag, func.count(Lead.id))
                .where(Lead.tag.isnot(None))
                .group_by(Lead.tag)
                .order_by(func.count(Lead.id).desc())
                .limit(10)
            )
        ).all()
        tags = {t: c for t, c in tags_raw}

        # Average lead score
        avg_score = (await session.exec(select(func.avg(Lead.lead_score)))).one() or 0

    return {
        "total_leads": total,
        "no_website": no_website,
        "has_website": has_website,
        "with_phone": with_phone,
        "with_email": with_email,
        "grades": {"A": grade_a, "B": grade_b, "C": grade_c, "D": grade_d},
        "sources": sources,
        "tags": tags,
        "avg_lead_score": round(float(avg_score), 1),
    }


# ── Scheduled searches ───────────────────────────────────────────
@router.post("/schedules")
async def create_schedule(req: ScheduleRequest) -> Dict[str, Any]:
    async with session_factory() as session:
        sched = ScheduledSearch(
            search_type=req.search_type,
            query=req.query,
            max_results=req.max_results,
            tag=req.tag,
            only_no_website=req.only_no_website,
            interval_minutes=req.interval_minutes,
        )
        session.add(sched)
        await session.commit()
        await session.refresh(sched)
        return {"created": True, "schedule": sched.model_dump()}


@router.get("/schedules")
async def list_schedules() -> List[ScheduledSearch]:
    async with session_factory() as session:
        rows = (await session.exec(select(ScheduledSearch).order_by(ScheduledSearch.created_at.desc()))).all()
        return list(rows)


@router.delete("/schedules/{schedule_id}")
async def delete_schedule(schedule_id: int) -> Dict[str, Any]:
    async with session_factory() as session:
        row = await session.get(ScheduledSearch, schedule_id)
        if not row:
            raise HTTPException(status_code=404, detail="Not found")
        await session.delete(row)
        await session.commit()
    return {"deleted": True, "id": schedule_id}


@router.post("/schedules/{schedule_id}/run")
async def run_schedule_now(schedule_id: int) -> Dict[str, Any]:
    async with session_factory() as session:
        sched = await session.get(ScheduledSearch, schedule_id)
        if not sched:
            raise HTTPException(status_code=404, detail="Not found")
        query = sched.query
        max_results = sched.max_results
        tag = sched.tag
        only_no_website = sched.only_no_website
        search_type = sched.search_type

    if search_type == "maps":
        result = await run_maps_search(
            query=query, max_results=max_results, tag=tag, only_no_website=only_no_website
        )
    else:
        result = await run_search_and_collect(
            engine="bing", query=query, location_hint=None,
            max_results=max_results, tag=tag, only_no_website=only_no_website
        )

    async with session_factory() as session:
        sched = await session.get(ScheduledSearch, schedule_id)
        if sched:
            sched.last_run_at = datetime.utcnow()
            sched.total_runs += 1
            sched.total_leads_found += result.get("saved", 0)
            session.add(sched)
            await session.commit()

    return result
