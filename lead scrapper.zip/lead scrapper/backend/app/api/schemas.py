from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field


SearchEngine = Literal["google", "bing", "ddg"]


class SearchRequest(BaseModel):
    engine: SearchEngine = "google"
    query: str = Field(min_length=2)
    location_hint: Optional[str] = None
    max_results: int = Field(default=20, ge=1, le=200)
    tag: Optional[str] = None
    only_no_website: bool = False


class MapsSearchRequest(BaseModel):
    query: str = Field(min_length=2)
    max_results: int = Field(default=20, ge=1, le=100)
    tag: Optional[str] = None
    only_no_website: bool = False


class ScanUrlRequest(BaseModel):
    url: str
    engine: SearchEngine = "google"
    search_query: str = ""
    tag: Optional[str] = None


class ScheduleRequest(BaseModel):
    search_type: str = "maps"
    query: str = Field(min_length=2)
    max_results: int = Field(default=20, ge=1, le=100)
    tag: Optional[str] = None
    only_no_website: bool = True
    interval_minutes: int = Field(default=60, ge=5, le=1440)
